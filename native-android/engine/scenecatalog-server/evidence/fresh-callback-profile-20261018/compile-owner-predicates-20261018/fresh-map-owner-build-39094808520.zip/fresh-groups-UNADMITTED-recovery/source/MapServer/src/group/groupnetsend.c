#include "../../../libs/UtilitiesLib/src/utils/coh_fresh_source_profile_api.h"
#include "group/group.h"
#include <utilitieslib/network/netio.h>
#include <utilitieslib/utils/timing.h>
#include "comm_game.h"
#include "groupjournal.h"
#include <utilitieslib/network/netcomp.h>
#include "group/groupProperties.h"
#include "dbcomm/dbcomm.h"
#include <utilitieslib/utils/error.h>
#include <utilitieslib/utils/utils.h>
#include "cmdparse/cmdserver.h"
#include "seq/anim.h"
#include "bases/basesend.h"
#include "storyarc/mission.h"
#include "beacon/beaconFile.h"
#include "bases/bases.h"
#include "gameSys/sgraid_V2.h"
#include "dbcomm/staticMapInfo.h"

int        world_id;
char    world_name[MAX_PATH];
static GroupDef **pendingDynamicDefChanges;

static void sendAllBounds(Packet *pak)
{
    int        k,i;

    pktSendBitsPack(pak,1,group_info.file_count);
    for(k=0;k<group_info.file_count;k++)
    {
        GroupFile    *file = group_info.files[k];

        pktSendString(pak,file->fullname);
        pktSendBitsPack(pak,1,file->count);
        for(i=0;i<file->count;i++)
        {
            pktSendString(pak,file->defs[i]->name);
            pktSendF32(pak,file->defs[i]->vis_dist);
        }
    }
}

static void sendDef(Packet *pak,GroupDef *def)
{
    int            j;
    GroupEnt    *ent;

    pktSendBitsPack(pak,1,def->id+1);
    pktSendBits(pak,1,def->in_use);
    if (!def->in_use)
        return;

    pktSendString(pak,def->name);

    pktSendBits(pak,32,def->mod_time);

    pktSendBitsPack(pak,1,def->count);
    for(j=0;j<def->count;j++)
    {
        ent = &def->entries[j];
        pktSendString(pak,ent->def->name);
        sendMat4(pak,ent->mat);
    }


    // LOD stuff
    if (def->lod_scale || def->lod_near || def->lod_far || def->lod_nearfade || def->lod_farfade
            || def->lod_fadenode || def->no_fog_clip || def->no_coll || def->child_parent_fade || def->parent_fade)
    {
        pktSendBits(pak,1,1);
        pktSendIfSetF32(pak,def->lod_scale);
        pktSendIfSetF32(pak,def->lod_near);
        pktSendIfSetF32(pak,def->lod_far);
        pktSendIfSetF32(pak,def->lod_nearfade);
        pktSendIfSetF32(pak,def->lod_farfade);
        pktSendBits(pak,2,def->lod_fadenode);
        pktSendBits(pak,1,def->parent_fade);
        pktSendBits(pak,1,def->child_parent_fade);
        pktSendBits(pak,1,def->no_fog_clip);
        pktSendBits(pak,1,def->no_coll);
    }
    else
        pktSendBits(pak,1,0);

    // Child / open Tracker stuff
    // Maybe just have open_tracker?
    if (def->child_light || def->child_ambient || def->child_volume || def->child_beacon || def->open_tracker || def->child_no_fog_clip)
    {
        pktSendBits(pak,1,1);
        pktSendBits(pak,1,def->open_tracker);
        pktSendBits(pak,1,def->child_light);
        pktSendBits(pak,1,def->child_ambient);
        pktSendBits(pak,1,def->child_volume);
        pktSendBits(pak,1,def->child_beacon);
        pktSendBits(pak,1,def->child_no_fog_clip);
        //Note: def->child_properties is not send down to the client currently (is it needed?)
    }
    else
        pktSendBits(pak,1,0);

    pktSendIfSetF32(pak,def->sound_radius);
    pktSendIfSetF32(pak,def->shadow_dist);

    // Various tricks
    if (def->has_light || def->has_cubemap || def->has_ambient || def->lib_ungroupable
        || def->has_sound || def->has_volume || def->has_fog || def->has_beacon 
        || def->has_tint_color || def->has_tex || (def->type_name && def->type_name[0])
        || def->has_properties || def->has_alpha)
    {
        pktSendBits(pak,1,1);

        pktSendString(pak,def->type_name);

        pktSendBits(pak,1,def->lib_ungroupable);

        pktSendBits(pak,1,def->has_light);
        pktSendBits(pak,1,def->has_ambient);
        if (def->has_ambient || def->has_light)
        {
            if (def->has_light)
                pktSendIfSetF32(pak,def->light_radius);
            for(j=0;j<8;j++)
                pktSendBits(pak,8,def->color[0][j]);
        }

        pktSendBits(pak,1,def->has_cubemap);
        if (def->has_cubemap)
        {
            pktSendBits(pak,16,def->cubemapGenSize);
            pktSendBits(pak,16,def->cubemapCaptureSize);
            pktSendF32(pak,def->cubemapBlurAngle);
            pktSendF32(pak,def->cubemapCaptureTime);
        }

        pktSendBits(pak,1,def->has_sound);
        if (def->has_sound)
        {
            pktSendString(pak,def->sound_name);
            pktSendString(pak,def->sound_script_filename);
            pktSendBits(pak,8,def->sound_vol);
            pktSendF32(pak,def->sound_ramp);
            pktSendBits(pak,1,def->sound_exclude);
        }

        pktSendBits(pak,1,def->has_fog);
        if (def->has_fog)
        {
            pktSendF32(pak,def->fog_near);
            pktSendF32(pak,def->fog_far);
            pktSendF32(pak,def->fog_radius);
            pktSendF32(pak,def->fog_speed);
            for(j=0;j<8;j++)
                pktSendBits(pak,8,def->color[0][j]);
        }

        pktSendBits(pak,1,def->has_volume);
        if (def->has_volume)
        {
            pktSendF32(pak,def->box_scale[0]);
            pktSendF32(pak,def->box_scale[1]);
            pktSendF32(pak,def->box_scale[2]);
        }

        pktSendBits(pak, 1, def->has_beacon);
        if (def->has_beacon)
        {
            pktSendString(pak, def->beacon_name);
            pktSendF32(pak, def->beacon_radius);
        }
        pktSendBits(pak,1,def->has_tint_color);
        if (def->has_tint_color)
        {
            for(j=0;j<3;j++)
                pktSendBits(pak,8,def->color[0][j]);
            for(j=0;j<3;j++)
                pktSendBits(pak,8,def->color[1][j]);
        }

        pktSendBitsPack(pak,1,def->has_tex);
        if (def->has_tex & 1)
            pktSendString(pak,def->tex_names[0]);
        if (def->has_tex & 2)
            pktSendString(pak,def->tex_names[1]);
        
        pktSendBits(pak,1,def->has_alpha);
        if (def->has_alpha)
            pktSendF32(pak, def->groupdef_alpha);

        pktSendBitsPack(pak,1,def->has_properties);
        if(def->has_properties)
        {
            WriteGroupPropertiesToPacket(pak, def->properties);
        }
    }
    else
        pktSendBits(pak,1,0);

    pktSendBitsPack(pak,1,eaSize(&def->def_tex_swaps));
    {
        int k;
        for (k=0;k<eaSize(&def->def_tex_swaps);k++) {
            pktSendString(pak,def->def_tex_swaps[k]->tex_name);
            pktSendString(pak,def->def_tex_swaps[k]->replace_name);
            pktSendBits(pak,1,def->def_tex_swaps[k]->composite);
        }
    }

    pktSendBits(pak,1,def->model ? 1 : 0);
    if (def->model)
    {
        pktSendString(pak,def->model->name);
    }
    pktSendBits(pak,1,def->hideForGameplay);
}

static void sendGroupFile(GroupFile *file,NetLink *link,int full_update,Packet *pak,U32 *mod_time_p)
{
    extern Base g_base;
    int            i;
    GroupDef    *def;

static int use_compressed_base = 1;

    if ((!full_update && file->mod_time <= link->last_update_time) && !file->force_reload)
    {
        pktSendBits(pak,1,0);
        return;
    }
    pktSendBits(pak, 1, 1);
    pktSendString(pak, file->fullname);
    pktSendBits(pak, 32, file->bounds_checksum);
    if (file->base && file->base == &g_base)
    {
        pktSendBits(pak, 1, 1);
        pktSendBits(pak, 1, 0);
        baseSendAll(pak, file->base, file->mod_time, full_update);
        return;
    }
    else if (full_update && use_compressed_base && g_isBaseRaid)
    {
        int numbase = eaSize(&g_raidbases);
        pktSendBits(pak, 1, 1);
        pktSendBits(pak, 1 ,1);

        pktSendBits(pak, 32, g_baseRaidType);
        pktSendBits(pak, 32, numbase);
        for (i = 0; i < numbase; i++)
        {
            if (i < numbase - 1)
            {
                pktSendBits(pak, 32, sgRaidGetBaseRaidSGID(i));
                pktSendBits(pak, 32, sgRaidGetBaseRaidRaidID(i));
            }
            pktSendF32(pak, g_baseraidOffsets[i][0]);
            pktSendF32(pak, g_baseraidOffsets[i][1]);
            pktSendF32(pak, g_baseraidOffsets[i][2]);
            baseSendAll(pak, g_raidbases[i], g_raidbases[i]->mod_time, full_update);
        }

        for(i = 0; i < file->count; i++)
        {
            def = file->defs[i];
            def->mod_time = link->last_update_time;
        }
        if (link->last_update_time > *mod_time_p)
        {
            *mod_time_p = link->last_update_time;
        }
        file->force_reload = 0;
        return;
    }
    pktSendBits(pak,1,0);
    for(i=0;i<file->count;i++)
    {
        def = file->defs[i];
        if (!file->force_reload) {
            if (!full_update && def->mod_time <= link->last_update_time)
                continue;
            if (!file->modified_on_disk && def->file_idx && def->saved)
                continue;
        }
        if (def->mod_time > *mod_time_p)
            *mod_time_p = def->mod_time;
        sendDef(pak,def);
    }
    file->force_reload=0;
    pktSendBitsPack(pak,1,0);
}

static void sendLoadScreenPages(Packet *pak)
{
    const MapSpec *mapSpec = MapSpecFromMapId(db_state.base_map_id);
    const MissionDef *missiondef;
    int index, count;

    if (g_activemission
        && (missiondef = TaskMissionDefinition(&g_activemission->sahandle))
        && (count = eaSize(&missiondef->loadScreenPages)))
    {
        pktSendBits(pak, 1, 1);
        pktSendBitsAuto(pak, count);
        for (index = 0; index < count; index++)
        {
            pktSendString(pak, missiondef->loadScreenPages[index]);
        }
    }
    else if (mapSpec)
    {
        count = eaSize(&mapSpec->loadScreenPages);

        pktSendBits(pak, 1, 1);
        pktSendBitsAuto(pak, count);
        for (index = 0; index < count; index++)
        {
            pktSendString(pak, mapSpec->loadScreenPages[index]);
        }
    }
    else
    {
        // not sending load screen pages
        pktSendBits(pak, 1, 0);
    }
}


#include "svr/svr_base.h"
#include "entity/entity.h"
#include "entity/character_base.h"
#include "seq/tricks.h"
/* Include after the unchanged original groupnetsend.c in the SAME translation
 * unit, where its static sendDef is visible. The embedding server initializes
 * the normal packet subsystem and supplies an exclusive, stable group_info
 * snapshot for the whole call, including callbacks. Original property writing
 * also uses process globals, so concurrent packet/property serialization is
 * not supported. No GroupDef, GroupFile, tracker or NetLink is modified here.
 *
 * The output callback must consume/copy each span before returning exactly 1.
 * It must stage output until success: a callback error or a changed snapshot
 * can leave a partial envelope. This adapter never sends a packet, opens a
 * file, or uses a network link. asset_generation is a caller-owned identity,
 * not a claim that this source snapshot is authoritative for another asset set.
 *
 * All records are the complete unmodified sendDef output, including id+1.
 * pktSetCompression(...,1) selects byte-aligned field encoding; no packet
 * transport header or zlib compression is applied. Private packet debug tags
 * are disabled. The original trusted packet allocator may grow transiently
 * before the record admission limit is checked. These output limits are not a
 * hard allocation bound on that upstream allocator; the native catalog decoder
 * must independently enforce its input and ownership budgets.
 */
#ifndef COH_SOURCE_CATALOG_EXPORT_INCLUDED
#define COH_SOURCE_CATALOG_EXPORT_INCLUDED

#include <string.h>

typedef char CohSourceCatalogU32MustHaveFourBytes[
    sizeof(unsigned int) == 4 ? 1 : -1];

#define COH_SOURCE_CATALOG_VERSION 1u
#define COH_SOURCE_CATALOG_HEADER_BYTES 48u
#define COH_SOURCE_CATALOG_MAX_FILES 1024u
#define COH_SOURCE_CATALOG_MAX_SLOTS 65536u
#define COH_SOURCE_CATALOG_MAX_DEFINITIONS 65536u
#define COH_SOURCE_CATALOG_MAX_CHILDREN 262144u
#define COH_SOURCE_CATALOG_MAX_ACTIVE_ROOTS 65536u
#define COH_SOURCE_CATALOG_MAX_ROOT_SLOTS 65536u
#define COH_SOURCE_CATALOG_MAX_NAME_BYTES 256u
#define COH_SOURCE_CATALOG_MAX_RECORD_BYTES (4u * 1024u * 1024u)
#define COH_SOURCE_CATALOG_MAX_BYTES (32u * 1024u * 1024u)
#define COH_SOURCE_CATALOG_NO_INDEX 0xffffffffu

typedef int (*CohSourceCatalogOutputFn)(void *context,
    const unsigned char *bytes, unsigned int size);

typedef enum CohSourceCatalogExportStatus
{
    COH_SOURCE_CATALOG_OK = 0,
    COH_SOURCE_CATALOG_ARGUMENT = 1,
    COH_SOURCE_CATALOG_LIMIT = 2,
    COH_SOURCE_CATALOG_SOURCE = 3,
    COH_SOURCE_CATALOG_PACKET = 4,
    COH_SOURCE_CATALOG_OUTPUT = 5,
    COH_SOURCE_CATALOG_CHANGED = 6
} CohSourceCatalogExportStatus;

typedef struct CohSourceCatalogExportReport
{
    unsigned int status;
    unsigned int failure_file;
    unsigned int failure_slot;
    unsigned int files;
    unsigned int definitions;
    unsigned int slots;
    unsigned int children;
    unsigned int wire_bytes;
    unsigned int total_bytes;
    unsigned int emitted_bytes;
} CohSourceCatalogExportReport;

static int coh_source_catalog_fail(CohSourceCatalogExportReport *report,
    int status, unsigned int file, unsigned int slot)
{
    report->status = (unsigned int)status;
    report->failure_file = file;
    report->failure_slot = slot;
    return status;
}

/* Match the decoder's nonempty visible-ASCII name admission exactly. Returns
 * bytes including NUL, or zero for an inadmissible or overlong source name. */
static unsigned int coh_source_catalog_name_bytes(const char *name)
{
    unsigned int i;
    unsigned char c;
    if (!name)
        return 0;
    for (i = 0; i < COH_SOURCE_CATALOG_MAX_NAME_BYTES; ++i)
    {
        c = (unsigned char)name[i];
        if (!c)
            return i ? i + 1u : 0;
        if (c < 32u || c > 126u)
            return 0;
    }
    return 0;
}

static int coh_source_catalog_same_name(const char *a, const char *b)
{
    unsigned int ca, cb;
    while (*a && *b)
    {
        ca = (unsigned char)*a++;
        cb = (unsigned char)*b++;
        if (ca >= 'A' && ca <= 'Z')
            ca += 'a' - 'A';
        if (cb >= 'A' && cb <= 'Z')
            cb += 'a' - 'A';
        if (ca != cb)
            return 0;
    }
    return *a == *b;
}

static void coh_source_catalog_put_u32(unsigned char *out, unsigned int value)
{
    out[0] = (unsigned char)value;
    out[1] = (unsigned char)(value >> 8);
    out[2] = (unsigned char)(value >> 16);
    out[3] = (unsigned char)(value >> 24);
}

static int coh_source_catalog_emit(CohSourceCatalogOutputFn output,
    void *context, CohSourceCatalogExportReport *report,
    const unsigned char *bytes, unsigned int size,
    unsigned int file, unsigned int slot)
{
    if (size > report->total_bytes - report->emitted_bytes)
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_CHANGED,
            file, slot);
    if (output(context, bytes, size) != 1)
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_OUTPUT,
            file, slot);
    report->emitted_bytes += size;
    return COH_SOURCE_CATALOG_OK;
}

/* Packet ownership always stays with this adapter. Every successful return
 * gives the caller one packet which it must pktFree after using stream.data. */
static Packet *coh_source_catalog_record(GroupDef *def,
    unsigned int *wire_bits, unsigned int *wire_bytes)
{
    Packet *pak;
    pak = pktCreate();
    if (!pak)
        return 0;
    pak->hasDebugInfo = 0;
    pktSetCompression(pak, 1);
    sendDef(pak, def);
    *wire_bits = pak->stream.bitLength;
    *wire_bytes = *wire_bits / 8u;
    if (pak->stream.errorFlags || !pak->stream.data ||
        !pak->stream.byteAlignedMode || (*wire_bits & 7u) ||
        pak->stream.cursor.bit || pak->stream.cursor.byte != *wire_bytes ||
        !*wire_bytes)
    {
        pktFree(pak);
        return 0;
    }
    return pak;
}

/* Returns COH_SOURCE_CATALOG_OK (zero) on complete success. The report is
 * optional, and retains the measured counts and successfully emitted byte
 * count on failure. Null slots are represented only by file.slot_count;
 * allocated tombstones are actual sendDef records and are never omitted. */
int coh_source_catalog_export(CohSourceCatalogOutputFn output, void *context,
    unsigned int asset_generation, CohSourceCatalogExportReport *report)
{
    CohSourceCatalogExportReport local_report;
    unsigned int records[COH_SOURCE_CATALOG_MAX_FILES];
    unsigned char header[COH_SOURCE_CATALOG_HEADER_BYTES];
    unsigned char fields[20];
    unsigned int file_count, root_slots, f, s, j, count, name_bytes;
    unsigned int wire_bits, wire_bytes, active_roots, defs_crc, refs_crc;
    unsigned int second_definitions, second_wire_bytes, second_slots;
    unsigned int second_children, second_records;
    int status;
    GroupFile *file;
    GroupDef *def;
    Packet *pak;

    if (!report)
        report = &local_report;
    memset(report, 0, sizeof(*report));
    report->failure_file = COH_SOURCE_CATALOG_NO_INDEX;
    report->failure_slot = COH_SOURCE_CATALOG_NO_INDEX;
    report->total_bytes = COH_SOURCE_CATALOG_HEADER_BYTES;
    if (!output || !asset_generation)
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_ARGUMENT,
            COH_SOURCE_CATALOG_NO_INDEX, COH_SOURCE_CATALOG_NO_INDEX);
    if (group_info.file_count < 0 ||
        (unsigned int)group_info.file_count > COH_SOURCE_CATALOG_MAX_FILES)
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_LIMIT,
            COH_SOURCE_CATALOG_NO_INDEX, COH_SOURCE_CATALOG_NO_INDEX);
    if (group_info.ref_count >= 0 &&
        (unsigned int)group_info.ref_count > COH_SOURCE_CATALOG_MAX_ROOT_SLOTS)
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_LIMIT,
            COH_SOURCE_CATALOG_NO_INDEX, COH_SOURCE_CATALOG_NO_INDEX);
    file_count = (unsigned int)group_info.file_count;
    report->files = file_count;
    if ((file_count && !group_info.files) || group_info.ref_count < 0 ||
        (group_info.ref_count && !group_info.refs))
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_SOURCE,
            COH_SOURCE_CATALOG_NO_INDEX, COH_SOURCE_CATALOG_NO_INDEX);

    root_slots = (unsigned int)group_info.ref_count;

    /* First pass validates the source shape and measures native bytes before
     * any callback is invoked. It never invokes sendGroupFile, whose normal
     * saved-definition filtering and force_reload mutation are inappropriate. */
    for (f = 0; f < file_count; ++f)
    {
        file = group_info.files[f];
        if (!file || file->count < 0 || (file->count && !file->defs))
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_SOURCE,
                f, COH_SOURCE_CATALOG_NO_INDEX);
        count = (unsigned int)file->count;
        if (count > COH_SOURCE_CATALOG_MAX_SLOTS - report->slots)
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_LIMIT,
                f, COH_SOURCE_CATALOG_NO_INDEX);
        name_bytes = coh_source_catalog_name_bytes(file->fullname);
        if (!name_bytes)
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_SOURCE,
                f, COH_SOURCE_CATALOG_NO_INDEX);
        for (j = 0; j < f; ++j)
        {
            if (coh_source_catalog_same_name(file->fullname,
                group_info.files[j]->fullname))
                return coh_source_catalog_fail(report,
                    COH_SOURCE_CATALOG_SOURCE, f, COH_SOURCE_CATALOG_NO_INDEX);
        }
        if (20u + name_bytes >
            COH_SOURCE_CATALOG_MAX_BYTES - report->total_bytes)
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_LIMIT,
                f, COH_SOURCE_CATALOG_NO_INDEX);
        report->total_bytes += 20u + name_bytes;
        report->slots += count;
        records[f] = 0;
        for (s = 0; s < count; ++s)
        {
            def = file->defs[s];
            if (!def)
                continue;
            if (def->id < 0 || (unsigned int)def->id != s ||
                def->in_use > 1)
                return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_SOURCE,
                    f, s);
            if (report->definitions == COH_SOURCE_CATALOG_MAX_DEFINITIONS)
                return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_LIMIT,
                    f, s);
            ++report->definitions;
            ++records[f];
            if (def->in_use)
            {
                if (def->count < 0 || (def->count && !def->entries) ||
                    !coh_source_catalog_name_bytes(def->name) ||
                    !def->name[0])
                    return coh_source_catalog_fail(report,
                        COH_SOURCE_CATALOG_SOURCE, f, s);
                if ((unsigned int)def->count >
                    COH_SOURCE_CATALOG_MAX_CHILDREN - report->children)
                    return coh_source_catalog_fail(report,
                        COH_SOURCE_CATALOG_LIMIT, f, s);
                report->children += (unsigned int)def->count;
                for (j = 0; j < (unsigned int)def->count; ++j)
                {
                    if (!def->entries[j].def ||
                        !coh_source_catalog_name_bytes(
                            def->entries[j].def->name) ||
                        !def->entries[j].def->name[0])
                        return coh_source_catalog_fail(report,
                            COH_SOURCE_CATALOG_SOURCE, f, s);
                }
            }
            pak = coh_source_catalog_record(def, &wire_bits, &wire_bytes);
            if (!pak)
                return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_PACKET,
                    f, s);
            if (wire_bytes > COH_SOURCE_CATALOG_MAX_RECORD_BYTES ||
                wire_bytes + 16u >
                    COH_SOURCE_CATALOG_MAX_BYTES - report->total_bytes)
            {
                pktFree(pak);
                return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_LIMIT,
                    f, s);
            }
            report->wire_bytes += wire_bytes;
            report->total_bytes += 16u + wire_bytes;
            pktFree(pak);
        }
    }
    /* These are the independent original traversal functions. Check the
     * tracker pointers they dereference before invoking either CRC oracle. */
    for (s = 0; s < root_slots; ++s)
    {
        if (!group_info.refs[s])
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_SOURCE,
                COH_SOURCE_CATALOG_NO_INDEX, s);
        def = group_info.refs[s]->def;
        if (def && def->count && !def->entries)
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_SOURCE,
                COH_SOURCE_CATALOG_NO_INDEX, s);
    }
    defs_crc = (unsigned int)groupInfoCrcDefs();
    refs_crc = (unsigned int)groupInfoCrcRefs();
    active_roots = (unsigned int)groupInfoRefCount();
    if (active_roots > COH_SOURCE_CATALOG_MAX_ACTIVE_ROOTS)
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_LIMIT,
            COH_SOURCE_CATALOG_NO_INDEX, COH_SOURCE_CATALOG_NO_INDEX);

    memset(header, 0, sizeof(header));
    memcpy(header, "COHCAT01", 8);
    coh_source_catalog_put_u32(header + 8, COH_SOURCE_CATALOG_VERSION);
    coh_source_catalog_put_u32(header + 12, COH_SOURCE_CATALOG_HEADER_BYTES);
    coh_source_catalog_put_u32(header + 16, report->total_bytes);
    coh_source_catalog_put_u32(header + 20, asset_generation);
    coh_source_catalog_put_u32(header + 24, file_count);
    coh_source_catalog_put_u32(header + 28, report->definitions);
    coh_source_catalog_put_u32(header + 32, defs_crc);
    coh_source_catalog_put_u32(header + 36, refs_crc);
    coh_source_catalog_put_u32(header + 40, active_roots);
    status = coh_source_catalog_emit(output, context, report, header,
        sizeof(header), COH_SOURCE_CATALOG_NO_INDEX, COH_SOURCE_CATALOG_NO_INDEX);
    if (status)
        return status;

    second_definitions = 0;
    second_wire_bytes = 0;
    second_slots = 0;
    second_children = 0;
    for (f = 0; f < file_count; ++f)
    {
        if (group_info.file_count != (int)file_count || !group_info.files ||
            !(file = group_info.files[f]) || file->count < 0 ||
            (file->count && !file->defs))
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_CHANGED,
                f, COH_SOURCE_CATALOG_NO_INDEX);
        count = (unsigned int)file->count;
        name_bytes = coh_source_catalog_name_bytes(file->fullname);
        if (!name_bytes || count > COH_SOURCE_CATALOG_MAX_SLOTS - second_slots)
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_CHANGED,
                f, COH_SOURCE_CATALOG_NO_INDEX);
        second_slots += count;
        coh_source_catalog_put_u32(fields, f);
        coh_source_catalog_put_u32(fields + 4, (unsigned int)file->bounds_checksum);
        coh_source_catalog_put_u32(fields + 8, count);
        coh_source_catalog_put_u32(fields + 12, records[f]);
        coh_source_catalog_put_u32(fields + 16, name_bytes);
        status = coh_source_catalog_emit(output, context, report, fields,
            20u, f, COH_SOURCE_CATALOG_NO_INDEX);
        if (status)
            return status;
        status = coh_source_catalog_emit(output, context, report,
            (const unsigned char *)file->fullname, name_bytes, f,
            COH_SOURCE_CATALOG_NO_INDEX);
        if (status)
            return status;
        second_records = 0;
        for (s = 0; s < count; ++s)
        {
            def = file->defs[s];
            if (!def)
                continue;
            if (def->id < 0 || (unsigned int)def->id != s || def->in_use > 1 ||
                ++second_records > records[f])
                return coh_source_catalog_fail(report,
                    COH_SOURCE_CATALOG_CHANGED, f, s);
            if (def->in_use)
            {
                if (def->count < 0 || (def->count && !def->entries) ||
                    (unsigned int)def->count >
                        COH_SOURCE_CATALOG_MAX_CHILDREN - second_children ||
                    !coh_source_catalog_name_bytes(def->name) ||
                    !def->name[0])
                    return coh_source_catalog_fail(report,
                        COH_SOURCE_CATALOG_CHANGED, f, s);
                second_children += (unsigned int)def->count;
                for (j = 0; j < (unsigned int)def->count; ++j)
                {
                    if (!def->entries[j].def ||
                        !coh_source_catalog_name_bytes(
                            def->entries[j].def->name) ||
                        !def->entries[j].def->name[0])
                        return coh_source_catalog_fail(report,
                            COH_SOURCE_CATALOG_CHANGED, f, s);
                }
            }
            pak = coh_source_catalog_record(def, &wire_bits, &wire_bytes);
            if (!pak)
                return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_PACKET,
                    f, s);
            if (wire_bytes > COH_SOURCE_CATALOG_MAX_RECORD_BYTES)
            {
                pktFree(pak);
                return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_CHANGED,
                    f, s);
            }
            coh_source_catalog_put_u32(fields, s);
            coh_source_catalog_put_u32(fields + 4, wire_bits);
            coh_source_catalog_put_u32(fields + 8, wire_bytes);
            coh_source_catalog_put_u32(fields + 12, 1u);
            status = coh_source_catalog_emit(output, context, report, fields,
                16u, f, s);
            if (!status)
                status = coh_source_catalog_emit(output, context, report,
                    pak->stream.data, wire_bytes, f, s);
            pktFree(pak);
            if (status)
                return status;
            ++second_definitions;
            second_wire_bytes += wire_bytes;
        }
        if (second_records != records[f])
            return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_CHANGED,
                f, COH_SOURCE_CATALOG_NO_INDEX);
    }
    if (second_definitions != report->definitions ||
        second_slots != report->slots || second_children != report->children ||
        second_wire_bytes != report->wire_bytes ||
        report->emitted_bytes != report->total_bytes ||
        group_info.file_count != (int)file_count ||
        group_info.ref_count != (int)root_slots ||
        (unsigned int)groupInfoCrcDefs() != defs_crc ||
        (unsigned int)groupInfoCrcRefs() != refs_crc ||
        (unsigned int)groupInfoRefCount() != active_roots)
        return coh_source_catalog_fail(report, COH_SOURCE_CATALOG_CHANGED,
            COH_SOURCE_CATALOG_NO_INDEX, COH_SOURCE_CATALOG_NO_INDEX);
    return COH_SOURCE_CATALOG_OK;
}

#endif /* COH_SOURCE_CATALOG_EXPORT_INCLUDED */

/* NONSHIPPING source snapshot, appended after unchanged sendDef/sendMat4 and
 * source_export.inc. The caller owns a stable, exclusive group_info snapshot
 * for the complete catalog + sidecar pair. Callbacks may only copy/write bytes;
 * they must never yield into the engine, mutate objects or invoke lazy loaders.
 * This is not a network transaction, actor identity or render authorization.
 */
#ifndef COH_SOURCE_RUNTIME_SNAPSHOT_INCLUDED
#define COH_SOURCE_RUNTIME_SNAPSHOT_INCLUDED

#include <string.h>
#if defined(SERVER)
#include "group/groupfilelib.h"
/* Defined by the unchanged Common/group/group.c, absent from group.h. */
extern GroupInfo *group_ptr;
#endif

#define COH_SNAPSHOT_MAX_BYTES (16u * 1024u * 1024u)
#define COH_SNAPSHOT_MAX_EXTERNAL 64u
#define COH_SNAPSHOT_HEADER_BYTES 80u
#define COH_SNAPSHOT_BOUNDS_BYTES 60u
#define COH_SNAPSHOT_NO_INDEX 0xffffffffu

typedef struct CohSourceSnapshotReport
{
    unsigned int status, total_bytes, emitted_bytes;
    unsigned int root_slots, active_roots, external_count, external_children;
    unsigned int defs_crc, refs_crc;
} CohSourceSnapshotReport;

typedef struct CohSnapshotState
{
    GroupDef *external[COH_SNAPSHOT_MAX_EXTERNAL];
    unsigned int external_count, external_children;
    unsigned int files, slots, definitions, children, roots;
    unsigned int total, emitted, pass;
    CohSourceCatalogOutputFn output;
    void *context;
} CohSnapshotState;

static unsigned int coh_snapshot_u32(const unsigned char *p)
{
    return (unsigned int)p[0] | ((unsigned int)p[1] << 8) |
        ((unsigned int)p[2] << 16) | ((unsigned int)p[3] << 24);
}

static void coh_snapshot_float(unsigned char *out, const F32 *value)
{
    unsigned int bits;
    typedef char CohSnapshotFloatSize[sizeof(F32) == 4 ? 1 : -1];
    (void)sizeof(CohSnapshotFloatSize);
    memcpy(&bits, value, 4);
    coh_source_catalog_put_u32(out, bits);
}

static int coh_snapshot_finite(const unsigned char *raw, unsigned int floats)
{
    unsigned int i;
    for (i = 0; i < floats; ++i)
        if ((coh_snapshot_u32(raw + i * 4u) & 0x7f800000u) == 0x7f800000u)
            return 0;
    return 1;
}

/* Explicit named fields: never serialize native bitfield layout/padding. */
static void coh_snapshot_bounds(unsigned char out[COH_SNAPSHOT_BOUNDS_BYTES],
    const GroupDef *d)
{
    unsigned int i, flags = 0;
    for (i = 0; i < 3u; ++i)
    {
        coh_snapshot_float(out + i * 4u, &d->min[i]);
        coh_snapshot_float(out + 12u + i * 4u, &d->max[i]);
        coh_snapshot_float(out + 24u + i * 4u, &d->mid[i]);
    }
    coh_snapshot_float(out + 36, &d->vis_dist);
    coh_snapshot_float(out + 40, &d->radius);
    coh_snapshot_float(out + 44, &d->lod_scale);
    coh_snapshot_float(out + 48, &d->shadow_dist);
    coh_source_catalog_put_u32(out + 52, (unsigned int)d->recursive_count);
#define COH_SNAPSHOT_FLAG(n, bit) flags |= (d->n ? 1u : 0u) << bit
    COH_SNAPSHOT_FLAG(breakable, 0); COH_SNAPSHOT_FLAG(child_breakable, 1);
    COH_SNAPSHOT_FLAG(is_tray, 2); COH_SNAPSHOT_FLAG(child_tray, 3);
    COH_SNAPSHOT_FLAG(has_ambient, 4); COH_SNAPSHOT_FLAG(child_ambient, 5);
    COH_SNAPSHOT_FLAG(has_light, 6); COH_SNAPSHOT_FLAG(child_light, 7);
    COH_SNAPSHOT_FLAG(has_cubemap, 8); COH_SNAPSHOT_FLAG(child_cubemap, 9);
    COH_SNAPSHOT_FLAG(has_fog, 10); COH_SNAPSHOT_FLAG(child_has_fog, 11);
    COH_SNAPSHOT_FLAG(has_volume, 12); COH_SNAPSHOT_FLAG(child_volume, 13);
    COH_SNAPSHOT_FLAG(has_beacon, 14); COH_SNAPSHOT_FLAG(child_beacon, 15);
    COH_SNAPSHOT_FLAG(open_tracker, 16); COH_SNAPSHOT_FLAG(has_properties, 17);
    COH_SNAPSHOT_FLAG(child_properties, 18); COH_SNAPSHOT_FLAG(no_fog_clip, 19);
    COH_SNAPSHOT_FLAG(child_no_fog_clip, 20); COH_SNAPSHOT_FLAG(is_autogroup, 21);
    COH_SNAPSHOT_FLAG(child_volume_trigger, 22); COH_SNAPSHOT_FLAG(no_coll, 23);
    COH_SNAPSHOT_FLAG(do_welding, 24); COH_SNAPSHOT_FLAG(editor_visible_only, 25);
#undef COH_SNAPSHOT_FLAG
    coh_source_catalog_put_u32(out + 56, flags);
}

static int coh_snapshot_emit(CohSnapshotState *s, const unsigned char *p,
    unsigned int n)
{
    if (n > COH_SNAPSHOT_MAX_BYTES - s->emitted)
        return COH_SOURCE_CATALOG_LIMIT;
    if (s->pass && s->output(s->context, p, n) != 1)
        return COH_SOURCE_CATALOG_OUTPUT;
    s->emitted += n;
    return COH_SOURCE_CATALOG_OK;
}

/* Pointer incidence supplies external identity. Numeric pre_alloc IDs are
 * deliberately NOT unique and its defs/count do not enumerate future objects. */
static int coh_snapshot_identity(CohSnapshotState *s, GroupDef *d,
    unsigned int *kind, unsigned int *file, unsigned int *slot)
{
    unsigned int f, i;
    if (!d || d->in_use != 1 || d->id < 0 || !d->file ||
        !coh_source_catalog_name_bytes(d->name) || groupDefFind(d->name) != d)
        return COH_SOURCE_CATALOG_SOURCE;
    for (f = 0; f < s->files; ++f)
    {
        if (d->file != group_info.files[f])
            continue;
        if (d->pre_alloc || d->file->pre_alloc ||
            (unsigned int)d->id >= (unsigned int)d->file->count ||
            d->file->defs[d->id] != d)
            return COH_SOURCE_CATALOG_SOURCE;
        *kind = 1u; *file = f; *slot = (unsigned int)d->id;
        return COH_SOURCE_CATALOG_OK;
    }
    if (!group_info.pre_alloc || d->file != group_info.pre_alloc ||
        !d->pre_alloc || !d->file->pre_alloc)
        return COH_SOURCE_CATALOG_SOURCE;
    for (i = 0; i < s->external_count; ++i)
    {
        if (s->external[i] == d)
            break;
        if (coh_source_catalog_same_name(s->external[i]->name, d->name))
            return COH_SOURCE_CATALOG_SOURCE;
    }
    if (i == s->external_count)
    {
        if (s->pass || i == COH_SNAPSHOT_MAX_EXTERNAL)
            return s->pass ? COH_SOURCE_CATALOG_CHANGED : COH_SOURCE_CATALOG_LIMIT;
        s->external[s->external_count++] = d;
    }
    *kind = 2u; *file = COH_SNAPSHOT_NO_INDEX; *slot = i;
    return COH_SOURCE_CATALOG_OK;
}

static int coh_snapshot_children(CohSnapshotState *s, GroupDef *d,
    unsigned int *count)
{
    unsigned int i, j, kind, file, slot;
    unsigned char matrix[48];
    int status;
    if (d->count < 0 || (d->count && !d->entries) ||
        (unsigned int)d->count > COH_SOURCE_CATALOG_MAX_CHILDREN - *count)
        return COH_SOURCE_CATALOG_LIMIT;
    *count += (unsigned int)d->count;
    for (i = 0; i < (unsigned int)d->count; ++i)
    {
        if (!d->entries[i].mat) return COH_SOURCE_CATALOG_SOURCE;
        for (j = 0; j < 12u; ++j)
            coh_snapshot_float(matrix + j * 4u, &d->entries[i].mat[j / 3u][j % 3u]);
        if (!coh_snapshot_finite(matrix, 12u)) return COH_SOURCE_CATALOG_SOURCE;
        status = coh_snapshot_identity(s, d->entries[i].def, &kind, &file, &slot);
        if (status)
            return status;
    }
    return COH_SOURCE_CATALOG_OK;
}

static int coh_snapshot_inventory(CohSnapshotState *s)
{
    unsigned int f, i, kind, file, slot, slots = 0, defs = 0, children = 0;
    unsigned int external_children = 0;
    GroupFile *g;
    GroupDef *d;
    int status;
    if (group_ptr != &group_info || group_info.file_count < 0 ||
        (unsigned int)group_info.file_count != s->files ||
        (s->files && !group_info.files) || group_info.ref_count < 0 ||
        (unsigned int)group_info.ref_count != s->roots ||
        (s->roots && !group_info.refs))
        return COH_SOURCE_CATALOG_CHANGED;
    for (f = 0; f < s->files; ++f)
    {
        g = group_info.files[f];
        if (!g || g->pre_alloc || g->count < 0 || (g->count && !g->defs) ||
            (unsigned int)g->count > COH_SOURCE_CATALOG_MAX_SLOTS - slots)
            return COH_SOURCE_CATALOG_SOURCE;
        slots += (unsigned int)g->count;
        for (i = 0; i < (unsigned int)g->count; ++i)
        {
            d = g->defs[i];
            if (!d)
                continue;
            if (d->id != (int)i || d->file != g || d->pre_alloc || d->in_use > 1)
                return COH_SOURCE_CATALOG_SOURCE;
            ++defs;
            if (!d->in_use)
                continue;
            status = coh_snapshot_identity(s, d, &kind, &file, &slot);
            if (!status)
                status = coh_snapshot_children(s, d, &children);
            if (status)
                return status;
        }
    }
    for (i = 0; i < s->roots; ++i)
    {
        if (!group_info.refs[i])
            return COH_SOURCE_CATALOG_SOURCE;
        d = group_info.refs[i]->def;
        if (!d)
            continue;
        status = coh_snapshot_identity(s, d, &kind, &file, &slot);
        if (status)
            return status;
    }
    /* The bound grows as newly reached external children are discovered. */
    for (i = 0; i < s->external_count; ++i)
    {
        status = coh_snapshot_children(s, s->external[i], &external_children);
        if (status)
            return status;
    }
    if (external_children > COH_SOURCE_CATALOG_MAX_CHILDREN - children)
        return COH_SOURCE_CATALOG_LIMIT;
    if (slots != s->slots || defs != s->definitions || children != s->children)
        return COH_SOURCE_CATALOG_CHANGED;
    s->external_children = external_children;
    return COH_SOURCE_CATALOG_OK;
}

static int coh_snapshot_roots(CohSnapshotState *s)
{
    unsigned int i, j, kind, file, slot, bits, bytes, name;
    unsigned char head[32], raw[48];
    GroupDef *d;
    Packet *pak;
    int status;
    for (i = 0; i < s->roots; ++i)
    {
        memset(head, 0, sizeof(head));
        coh_source_catalog_put_u32(head, i);
        coh_source_catalog_put_u32(head + 12, COH_SNAPSHOT_NO_INDEX);
        coh_source_catalog_put_u32(head + 16, COH_SNAPSHOT_NO_INDEX);
        d = group_info.refs[i]->def;
        if (!d)
        {
            status = coh_snapshot_emit(s, head, sizeof(head));
            if (status) return status;
            continue;
        }
        status = coh_snapshot_identity(s, d, &kind, &file, &slot);
        if (status) return status;
        name = coh_source_catalog_name_bytes(d->name);
        for (j = 0; j < 12u; ++j)
            coh_snapshot_float(raw + j * 4u, &group_info.refs[i]->mat[j / 3u][j % 3u]);
        if (!coh_snapshot_finite(raw, 12u)) return COH_SOURCE_CATALOG_SOURCE;
        pak = pktCreate();
        if (!pak) return COH_SOURCE_CATALOG_PACKET;
        pak->hasDebugInfo = 0;
        pktSetCompression(pak, 1);
        sendMat4(pak, group_info.refs[i]->mat);
        bits = pak->stream.bitLength; bytes = bits / 8u;
        if (pak->stream.errorFlags || !pak->stream.data || !pak->stream.byteAlignedMode ||
            (bits & 7u) || bytes > 256u || !bytes)
        {
            pktFree(pak); return COH_SOURCE_CATALOG_PACKET;
        }
        coh_source_catalog_put_u32(head + 4, 1u);
        coh_source_catalog_put_u32(head + 8, kind);
        coh_source_catalog_put_u32(head + 12, file);
        coh_source_catalog_put_u32(head + 16, slot);
        coh_source_catalog_put_u32(head + 20, name);
        coh_source_catalog_put_u32(head + 24, bits);
        coh_source_catalog_put_u32(head + 28, bytes);
        status = coh_snapshot_emit(s, head, sizeof(head));
        if (!status) status = coh_snapshot_emit(s, (const unsigned char *)d->name, name);
        if (!status) status = coh_snapshot_emit(s, raw, sizeof(raw));
        if (!status) status = coh_snapshot_emit(s, pak->stream.data, bytes);
        pktFree(pak);
        if (status) return status;
    }
    return COH_SOURCE_CATALOG_OK;
}

static int coh_snapshot_external(CohSnapshotState *s)
{
    unsigned int i, kind, file, slot, bits, bytes, name, path_bytes;
    unsigned char head[36], bounds[2 * COH_SNAPSHOT_BOUNDS_BYTES];
    GroupDef *d, scratch;
    const char *path;
    Packet *pak;
    int status, found;
    for (i = 0; i < s->external_count; ++i)
    {
        d = s->external[i];
        status = coh_snapshot_identity(s, d, &kind, &file, &slot);
        if (status || kind != 2u || slot != i)
            return status ? status : COH_SOURCE_CATALOG_CHANGED;
        memset(&scratch, 0, sizeof(scratch));
        /* Original function copies into scratch only; never into the live d. */
        found = objectLibraryGetBounds(d->name, &scratch);
        if (found != 0 && found != 1) return COH_SOURCE_CATALOG_SOURCE;
        path = objectLibraryPathFromObj(d->name);
        path_bytes = path ? coh_source_catalog_name_bytes(path) : 0;
        if (path && !path_bytes) return COH_SOURCE_CATALOG_SOURCE;
        name = coh_source_catalog_name_bytes(d->name);
        coh_snapshot_bounds(bounds, d);
        coh_snapshot_bounds(bounds + COH_SNAPSHOT_BOUNDS_BYTES, &scratch);
        if (!coh_snapshot_finite(bounds, 13u) ||
            !coh_snapshot_finite(bounds + COH_SNAPSHOT_BOUNDS_BYTES, 13u)) return COH_SOURCE_CATALOG_SOURCE;
        pak = coh_source_catalog_record(d, &bits, &bytes);
        if (!pak) return COH_SOURCE_CATALOG_PACKET;
        if (bytes > COH_SOURCE_CATALOG_MAX_RECORD_BYTES)
        {
            pktFree(pak); return COH_SOURCE_CATALOG_LIMIT;
        }
        coh_source_catalog_put_u32(head, i);
        coh_source_catalog_put_u32(head + 4, (unsigned int)d->id);
        coh_source_catalog_put_u32(head + 8, 15u);
        coh_source_catalog_put_u32(head + 12, d->model ? 1u : 0u);
        coh_source_catalog_put_u32(head + 16, name);
        coh_source_catalog_put_u32(head + 20, bits);
        coh_source_catalog_put_u32(head + 24, bytes);
        coh_source_catalog_put_u32(head + 28, (unsigned int)found);
        coh_source_catalog_put_u32(head + 32, path_bytes);
        status = coh_snapshot_emit(s, head, sizeof(head));
        if (!status) status = coh_snapshot_emit(s, bounds, sizeof(bounds));
        if (!status) status = coh_snapshot_emit(s, (const unsigned char *)d->name, name);
        if (!status && path_bytes) status = coh_snapshot_emit(s, (const unsigned char *)path, path_bytes);
        if (!status) status = coh_snapshot_emit(s, pak->stream.data, bytes);
        pktFree(pak);
        if (status) return status;
    }
    return COH_SOURCE_CATALOG_OK;
}

/* catalog_header is the exact first48 bytes emitted by the immediately prior
 * successful unchanged catalog exporter. Its full bytes must subsequently
 * match the independently pinned retained SHA256 in the hosted wrapper. */
static int coh_source_runtime_snapshot_export(CohSourceCatalogOutputFn output,
    void *context, const unsigned char catalog_header[48],
    const CohSourceCatalogExportReport *catalog, CohSourceSnapshotReport *report)
{
    CohSnapshotState s;
    unsigned char header[COH_SNAPSHOT_HEADER_BYTES];
    unsigned int pass, defs_crc, refs_crc, active, original_external;
    int status = COH_SOURCE_CATALOG_ARGUMENT;
    if (!report) return COH_SOURCE_CATALOG_ARGUMENT;
    memset(report, 0, sizeof(*report));
    memset(&s, 0, sizeof(s));
    if (!output || !catalog_header || !catalog || catalog->status ||
        catalog->emitted_bytes != catalog->total_bytes ||
        memcmp(catalog_header, "COHCAT01", 8) ||
        coh_snapshot_u32(catalog_header + 8) != 1u ||
        coh_snapshot_u32(catalog_header + 12) != 48u ||
        coh_snapshot_u32(catalog_header + 16) != catalog->total_bytes ||
        !coh_snapshot_u32(catalog_header + 20) ||
        coh_snapshot_u32(catalog_header + 24) != catalog->files ||
        coh_snapshot_u32(catalog_header + 28) != catalog->definitions ||
        coh_snapshot_u32(catalog_header + 44)) goto done;
    s.files = catalog->files; s.slots = catalog->slots;
    s.definitions = catalog->definitions; s.children = catalog->children;
    if (s.files > COH_SOURCE_CATALOG_MAX_FILES ||
        s.slots > COH_SOURCE_CATALOG_MAX_SLOTS ||
        s.definitions > COH_SOURCE_CATALOG_MAX_DEFINITIONS ||
        s.children > COH_SOURCE_CATALOG_MAX_CHILDREN ||
        group_info.ref_count < 0 ||
        (unsigned int)group_info.ref_count > COH_SOURCE_CATALOG_MAX_ROOT_SLOTS)
    { status = COH_SOURCE_CATALOG_LIMIT; goto done; }
    s.roots = (unsigned int)group_info.ref_count;
    status = coh_snapshot_inventory(&s);
    if (status) goto done;
    defs_crc = (unsigned int)groupInfoCrcDefs();
    refs_crc = (unsigned int)groupInfoCrcRefs();
    active = (unsigned int)groupInfoRefCount();
    if (defs_crc != coh_snapshot_u32(catalog_header + 32) ||
        refs_crc != coh_snapshot_u32(catalog_header + 36) ||
        active != coh_snapshot_u32(catalog_header + 40))
    { status = COH_SOURCE_CATALOG_CHANGED; goto done; }
    original_external = s.external_count;
    memset(header, 0, sizeof(header)); memcpy(header, "COHRTS01", 8);
    coh_source_catalog_put_u32(header + 8, 1u);
    coh_source_catalog_put_u32(header + 12, sizeof(header));
    coh_source_catalog_put_u32(header + 20, coh_snapshot_u32(catalog_header + 20));
    coh_source_catalog_put_u32(header + 24, catalog->total_bytes);
    coh_source_catalog_put_u32(header + 28, s.files);
    coh_source_catalog_put_u32(header + 32, s.slots);
    coh_source_catalog_put_u32(header + 36, s.definitions);
    coh_source_catalog_put_u32(header + 40, s.children);
    coh_source_catalog_put_u32(header + 44, s.roots);
    coh_source_catalog_put_u32(header + 48, active);
    coh_source_catalog_put_u32(header + 52, s.external_count);
    coh_source_catalog_put_u32(header + 56, defs_crc);
    coh_source_catalog_put_u32(header + 60, refs_crc);
    s.output = output; s.context = context;
    for (pass = 0; pass < 2u; ++pass)
    {
        s.pass = pass; s.emitted = 0;
        status = coh_snapshot_inventory(&s);
        if (!status) status = coh_snapshot_emit(&s, header, sizeof(header));
        if (!status) status = coh_snapshot_roots(&s);
        if (!status) status = coh_snapshot_external(&s);
        if (status) goto done;
        if (!pass)
        {
            s.total = s.emitted;
            coh_source_catalog_put_u32(header + 16, s.total);
        }
    }
    status = coh_snapshot_inventory(&s);
    if (!status && (s.emitted != s.total || s.external_count != original_external ||
        (unsigned int)groupInfoCrcDefs() != defs_crc ||
        (unsigned int)groupInfoCrcRefs() != refs_crc ||
        (unsigned int)groupInfoRefCount() != active)) status = COH_SOURCE_CATALOG_CHANGED;
done:
    report->status = (unsigned int)status;
    report->total_bytes = s.total; report->emitted_bytes = s.pass ? s.emitted : 0;
    report->root_slots = s.roots; report->external_count = s.external_count;
    report->external_children = s.external_children;
    if (status == COH_SOURCE_CATALOG_OK)
    {
        report->active_roots = active; report->defs_crc = defs_crc; report->refs_crc = refs_crc;
    }
    return status;
}

#endif

/* NONSHIPPING observer: include after source_snapshot.inc, anim.h, tricks.h.
 * Stable exclusive owner-thread group_info AND model/library/trick state required.
 * Never loads resources, invokes modelFind/groupModelFind, or mutates source.
 * Output goes to an unpublished temporary file; any failure discards all bytes.
 * SERVER-only observations do not establish CLIENT material/LOD completeness.
 */
#ifndef COH_SOURCE_RESOURCES_INCLUDED
#define COH_SOURCE_RESOURCES_INCLUDED
#define COH_RESOURCE_HEADER 192u
#define COH_RESOURCE_RECORD_MAX (128u*1024u)
#define COH_RESOURCE_TOTAL_MAX (64u*1024u*1024u)
#define COH_RESOURCE_TEXTURE_MAX 256u
#define COH_RESOURCE_MODEL_MAX 65536u
#define COH_RESOURCE_ROW_WORK_MAX (64u*1024u*1024u)

typedef struct CohSourceResourceReport {
    unsigned status,total_bytes,emitted_bytes,records,models,missing_models,textures,model_row_comparisons;
    unsigned client_materials_available,client_lods_available,actual_runtime_executed;
} CohSourceResourceReport;

static int coh_resource_string(unsigned char*out,unsigned*at,const char*name,
    unsigned bound,unsigned*length,int optional)
{
    unsigned n=0,i;
    *length=0;
    if(!name)return optional?COH_SOURCE_CATALOG_OK:COH_SOURCE_CATALOG_SOURCE;
    while(n<bound&&name[n])++n;
    if(!n||n==bound)return COH_SOURCE_CATALOG_SOURCE;
    ++n;if(n>COH_RESOURCE_RECORD_MAX-*at)return COH_SOURCE_CATALOG_LIMIT;
    for(i=0;i+1<n;i++)if((unsigned char)name[i]<32||(unsigned char)name[i]>126)return COH_SOURCE_CATALOG_SOURCE;
    memcpy(out+*at,name,n);*at+=n;*length=n;return COH_SOURCE_CATALOG_OK;
}
static int coh_resource_record(CohSnapshotState*s,GroupDef*d,unsigned generation,
    unsigned char*out,unsigned*size,unsigned*texture_count,unsigned*remaining_rows)
{
    unsigned at=COH_RESOURCE_HEADER,kind,file,slot,n,row=0xffffffffu,i,found=0;
    const char*names[6];Model*m;GeoLoadData*g=NULL;TrickInfo*info=NULL;int status;
    if(!generation||!out||!size||!texture_count||!remaining_rows)return COH_SOURCE_CATALOG_ARGUMENT;
    status=coh_snapshot_identity(s,d,&kind,&file,&slot);if(status)return status;
    memset(out,0,COH_RESOURCE_HEADER);memcpy(out,"COHRES01",8);
    coh_source_catalog_put_u32(out+8,1);coh_source_catalog_put_u32(out+12,COH_RESOURCE_HEADER);
    coh_source_catalog_put_u32(out+20,generation);coh_source_catalog_put_u32(out+24,kind);
    coh_source_catalog_put_u32(out+28,file);coh_source_catalog_put_u32(out+32,slot);
    coh_source_catalog_put_u32(out+36,(unsigned)d->id);coh_source_catalog_put_u32(out+44,1);
    m=d->model;names[0]=d->name;names[1]=names[2]=names[3]=names[4]=NULL;
    names[5]=objectLibraryPathFromObj(d->name);
    if(m){
        g=m->gld;
        if(!g||!m->name||g->modelheader.model_count<0||(unsigned)g->modelheader.model_count>COH_RESOURCE_MODEL_MAX||!g->modelheader.models||m->vert_count<0||m->tri_count<0||m->tex_count<0||(unsigned)m->tex_count>COH_RESOURCE_TEXTURE_MAX||(m->tex_count&&!m->tex_idx)||g->texnames.count<0||(g->texnames.count&&!g->texnames.strings)||g->file_format_version<0||g->loadstate<0||g->loadstate==2||m->loadstate==2)return COH_SOURCE_CATALOG_SOURCE;
        if((unsigned)g->modelheader.model_count>*remaining_rows)return COH_SOURCE_CATALOG_LIMIT;
        *remaining_rows-=(unsigned)g->modelheader.model_count;
        for(i=0;i<(unsigned)g->modelheader.model_count;i++)if(g->modelheader.models[i]==m){row=i;found++;}
        if(found!=1)return COH_SOURCE_CATALOG_SOURCE;
        names[1]=m->name;names[2]=g->name;
        coh_source_catalog_put_u32(out+40,1);coh_source_catalog_put_u32(out+68,row);
        coh_source_catalog_put_u32(out+72,(unsigned)g->file_format_version);
        coh_source_catalog_put_u32(out+76,(unsigned)g->loadstate);coh_source_catalog_put_u32(out+80,(unsigned)m->loadstate);
        coh_source_catalog_put_u32(out+84,m->flags);coh_source_catalog_put_u32(out+88,(unsigned)m->vert_count);
        coh_source_catalog_put_u32(out+92,(unsigned)m->tri_count);coh_source_catalog_put_u32(out+96,(unsigned)m->tex_count);
        if(m->trick){
            coh_source_catalog_put_u32(out+100,1);coh_source_catalog_put_u32(out+108,(unsigned)m->trick->flags1);coh_source_catalog_put_u32(out+112,(unsigned)m->trick->flags2);
            info=m->trick->info;
            if(info){
                names[3]=info->name;names[4]=info->file_name;
                if(!names[3]||!names[4])return COH_SOURCE_CATALOG_SOURCE;
                coh_source_catalog_put_u32(out+104,1);coh_source_catalog_put_u32(out+116,(unsigned)info->model_flags);coh_source_catalog_put_u32(out+120,info->group_flags);
                coh_snapshot_float(out+168,&info->lod_near);coh_snapshot_float(out+172,&info->lod_far);
                coh_snapshot_float(out+176,&info->lod_nearfade);coh_snapshot_float(out+180,&info->lod_farfade);
                coh_snapshot_float(out+184,&info->lod_scale);coh_snapshot_float(out+188,&info->shadow_dist);
            }
        }
        for(i=0;i<3;i++){coh_snapshot_float(out+128+i*4,&m->min[i]);coh_snapshot_float(out+140+i*4,&m->max[i]);coh_snapshot_float(out+152+i*4,&m->scale[i]);}
        coh_snapshot_float(out+164,&m->radius);
        if(!coh_snapshot_finite(out+128,16))return COH_SOURCE_CATALOG_SOURCE;
    }else coh_source_catalog_put_u32(out+68,0xffffffffu);
    for(i=0;i<6;i++){
        status=coh_resource_string(out,&at,names[i],i==2?sizeof(g->name):256u,&n,i!=0&&(!m||i>2));if(status)return status;
        coh_source_catalog_put_u32(out+(i<5?48+i*4:124),n);
    }
    *texture_count=0;
    if(m)for(i=0;i<(unsigned)m->tex_count;i++){
        unsigned id=m->tex_idx[i].id;
        if(id>=(unsigned)g->texnames.count||at>COH_RESOURCE_RECORD_MAX-12)return COH_SOURCE_CATALOG_SOURCE;
        coh_source_catalog_put_u32(out+at,id);coh_source_catalog_put_u32(out+at+4,m->tex_idx[i].count);at+=12;
        status=coh_resource_string(out,&at,g->texnames.strings[id],256,&n,0);if(status)return status;
        coh_source_catalog_put_u32(out+at-n-4,n);(*texture_count)++;
    }
    coh_source_catalog_put_u32(out+16,at);*size=at;return COH_SOURCE_CATALOG_OK;
}
/* The observer reuses exact source snapshot pointer-incidence discovery. Catalog
 * export and runtime sidecar must already be retained at this SAME boundary.
 * Scratch is caller-owned >=128KiB; writes never escape on a failed caller
 * transaction. No implicit original catalog/snapshot recapture occurs here. */
static int coh_source_resources_export(CohSourceCatalogOutputFn output,void*context,
    const unsigned char*catalog_header,const CohSourceCatalogExportReport*catalog,
    unsigned char*scratch,unsigned scratch_bytes,CohSourceResourceReport*report)
{
    CohSnapshotState s;unsigned pass,f,i,n,textures,records,models,total,defs_crc,refs_crc;
    int status=COH_SOURCE_CATALOG_ARGUMENT;GroupDef*d;
    if(!report)return status;
    memset(report,0,sizeof(*report));report->status=(unsigned)status;
    if(!output||!catalog_header||!catalog||catalog->status||!scratch||scratch_bytes<COH_RESOURCE_RECORD_MAX)return status;
    if(memcmp(catalog_header,"COHCAT01",8)||coh_snapshot_u32(catalog_header+8)!=1||coh_snapshot_u32(catalog_header+12)!=48||coh_snapshot_u32(catalog_header+20)==0||coh_snapshot_u32(catalog_header+16)!=catalog->total_bytes||catalog->emitted_bytes!=catalog->total_bytes||catalog->total_bytes<48||catalog->total_bytes>COH_SOURCE_CATALOG_MAX_BYTES||coh_snapshot_u32(catalog_header+24)!=catalog->files||coh_snapshot_u32(catalog_header+28)!=catalog->definitions||coh_snapshot_u32(catalog_header+44)||catalog->files>COH_SOURCE_CATALOG_MAX_FILES||catalog->slots>COH_SOURCE_CATALOG_MAX_SLOTS||catalog->definitions>COH_SOURCE_CATALOG_MAX_DEFINITIONS||catalog->children>COH_SOURCE_CATALOG_MAX_CHILDREN)return status;
    memset(&s,0,sizeof(s));s.files=catalog->files;s.slots=catalog->slots;s.definitions=catalog->definitions;s.children=catalog->children;s.roots=(unsigned)group_info.ref_count;
    status=coh_snapshot_inventory(&s);if(status){report->status=(unsigned)status;return status;}
    defs_crc=(unsigned)groupInfoCrcDefs();refs_crc=(unsigned)groupInfoCrcRefs();
    if(defs_crc!=coh_snapshot_u32(catalog_header+32)||refs_crc!=coh_snapshot_u32(catalog_header+36)||(unsigned)groupInfoRefCount()!=coh_snapshot_u32(catalog_header+40)){report->status=COH_SOURCE_CATALOG_CHANGED;return COH_SOURCE_CATALOG_CHANGED;}
    records=models=total=0;
    for(pass=0;pass<2;pass++){
        unsigned emitted=0,r=0,m=0,t=0,remaining_rows=COH_RESOURCE_ROW_WORK_MAX;s.pass=pass;
        status=coh_snapshot_inventory(&s);if(status)goto done;
        for(f=0;f<s.files+s.external_count;f++){
            unsigned count=f<s.files?(unsigned)group_info.files[f]->count:1;
            for(i=0;i<count;i++){
                d=f<s.files?group_info.files[f]->defs[i]:s.external[f-s.files];
                if(!d||!d->in_use)continue;
                status=coh_resource_record(&s,d,coh_snapshot_u32(catalog_header+20),scratch,&n,&textures,&remaining_rows);if(status)goto done;
                if(n>COH_RESOURCE_TOTAL_MAX-emitted){status=COH_SOURCE_CATALOG_LIMIT;goto done;}
                if(pass&&output(context,scratch,n)!=1){status=COH_SOURCE_CATALOG_OUTPUT;goto done;}
                emitted+=n;r++;m+=!!d->model;t+=textures;
                if(pass)report->emitted_bytes=emitted;
            }
        }
        if(!pass){records=r;models=m;total=emitted;report->textures=t;report->model_row_comparisons=COH_RESOURCE_ROW_WORK_MAX-remaining_rows;}
        else if(records!=r||models!=m||total!=emitted||report->textures!=t||report->model_row_comparisons!=COH_RESOURCE_ROW_WORK_MAX-remaining_rows){status=COH_SOURCE_CATALOG_CHANGED;goto done;}
    }
    status=coh_snapshot_inventory(&s);
    if(!status&&((unsigned)groupInfoCrcDefs()!=defs_crc||(unsigned)groupInfoCrcRefs()!=refs_crc))status=COH_SOURCE_CATALOG_CHANGED;
done:report->status=(unsigned)status;report->total_bytes=total;report->records=records;report->models=models;report->missing_models=records-models;return status;
}
#endif

/* NONSHIPPING read-only original MapServer owner preparation. Include only after
 * actual original NetLink/ClientLink/Entity/Character/Array declarations and
 * character_IsInitialized/entInUse declarations. No hook, sink or installation.
 * Single exclusive original client/entity/link owner thread; no yield/lazy load.
 * All original objects/tables must be valid, stable and caller-disjoint. */
#ifndef COH_SOURCE_GROUPS_OWNER_INCLUDED
#define COH_SOURCE_GROUPS_OWNER_INCLUDED
#include <stdint.h>
#include <limits.h>
#include <string.h>
#if UINT_MAX != 0xffffffffu
#error source_owner_requires_32_bit_unsigned
#endif
#define COH_SOURCE_GROUPS_OWNER_BYTES 192u
#define COH_SOURCE_GROUPS_OWNER_MAX_LINKS 65536u
typedef struct CohSourceGroupsOwner {
 unsigned char wire[COH_SOURCE_GROUPS_OWNER_BYTES];
 unsigned links_scanned,link_slot,dbid,entity_id,server_index,protocol_version;
} CohSourceGroupsOwner;
static int coh_source_owner_disjoint(const void*a,size_t an,const void*b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;if(!an||!bn)return 1;if(!a||!b||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y)return 0;return x+an<=y||y+bn<=x;}
/* Output commits only after all checks. Source-only association of actual owned
 * client entity, NOT viewed/slave entity, crypto/native decode/world admission.
 * Narrow future capture policy: registered unique connected clean UDP link,
 * valid original initialized Character and exact table/backlink chain.
 * This is deliberately stricter than worldSendUpdate's generic call surface. */
static int coh_source_groups_prepare_owner(const NetLink*link,CohSourceGroupsOwner*out){
 const ClientLink*client;const Entity*entity;const Character*character;unsigned i,slot=0,incidence=0,client_incidence=0;unsigned words[46];CohSourceGroupsOwner candidate;
 if(coh_fresh_source_owner_failed((!link),COH_FRESH_OWNER_INPUT_LINK)||coh_fresh_source_owner_failed((!out),COH_FRESH_OWNER_INPUT_OUTPUT)||coh_fresh_source_owner_failed((!net_links.links),COH_FRESH_OWNER_LIST_ABSENT)||coh_fresh_source_owner_failed((net_links.links->size<=0),COH_FRESH_OWNER_LIST_EMPTY)||coh_fresh_source_owner_failed(((unsigned)net_links.links->size>COH_SOURCE_GROUPS_OWNER_MAX_LINKS),COH_FRESH_OWNER_LIST_LIMIT)||coh_fresh_source_owner_failed((!net_links.links->storage),COH_FRESH_OWNER_LIST_STORAGE)||coh_fresh_source_owner_failed((net_links.links->maxSize<net_links.links->size),COH_FRESH_OWNER_LIST_CAPACITY))return 0;
 if(coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),link,sizeof(*link))),COH_FRESH_OWNER_OUTPUT_LINK_ALIAS)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),&net_links,sizeof(net_links))),COH_FRESH_OWNER_OUTPUT_LIST_ALIAS)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),net_links.links,sizeof(*net_links.links))),COH_FRESH_OWNER_OUTPUT_ARRAY_ALIAS)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),net_links.links->storage,(size_t)net_links.links->size*sizeof(*net_links.links->storage))),COH_FRESH_OWNER_OUTPUT_STORAGE_ALIAS)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),&world_id,sizeof(world_id))),COH_FRESH_OWNER_OUTPUT_WORLD_ALIAS)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),&entities_max,sizeof(entities_max))),COH_FRESH_OWNER_OUTPUT_ENTITIES_MAX_ALIAS)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),entities,(size_t)MAX_ENTITIES_PRIVATE*sizeof(*entities))),COH_FRESH_OWNER_OUTPUT_ENTITY_TABLE_ALIAS)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),entity_state,(size_t)MAX_ENTITIES_PRIVATE*sizeof(*entity_state))),COH_FRESH_OWNER_OUTPUT_ENTITY_STATE_ALIAS))return 0;
 client=(const ClientLink*)link->userData;
 if(coh_fresh_source_owner_failed((!client),COH_FRESH_OWNER_CLIENT_ABSENT)||coh_fresh_source_owner_failed((client->link!=link),COH_FRESH_OWNER_CLIENT_BACKLINK)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),client,sizeof(*client))),COH_FRESH_OWNER_OUTPUT_CLIENT_ALIAS))return 0;
 entity=client->entity;
 if(coh_fresh_source_owner_failed((!entity),COH_FRESH_OWNER_ENTITY_ABSENT)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),entity,sizeof(*entity))),COH_FRESH_OWNER_OUTPUT_ENTITY_ALIAS)||coh_fresh_source_owner_failed((entity->client!=client),COH_FRESH_OWNER_ENTITY_BACKLINK)||coh_fresh_source_owner_failed((entity->db_id<=0),COH_FRESH_OWNER_ENTITY_DBID)||coh_fresh_source_owner_failed((!entity->id),COH_FRESH_OWNER_ENTITY_ID)||coh_fresh_source_owner_failed((entity->owner<1),COH_FRESH_OWNER_ENTITY_SLOT_LOW)||coh_fresh_source_owner_failed((entity->owner>=MAX_ENTITIES_PRIVATE),COH_FRESH_OWNER_ENTITY_SLOT_HIGH)||coh_fresh_source_owner_failed((entities_max<1),COH_FRESH_OWNER_ENTITY_TABLE_SIZE_LOW)||coh_fresh_source_owner_failed((entities_max>MAX_ENTITIES_PRIVATE),COH_FRESH_OWNER_ENTITY_TABLE_SIZE_HIGH)||coh_fresh_source_owner_failed((!entInUse(entity->owner)),COH_FRESH_OWNER_ENTITY_NOT_IN_USE)||coh_fresh_source_owner_failed((entities[entity->owner]!=entity),COH_FRESH_OWNER_ENTITY_TABLE_MISMATCH))return 0;
 character=entity->pchar;
 if(coh_fresh_source_owner_failed((!character),COH_FRESH_OWNER_CHARACTER_ABSENT)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),character,sizeof(*character))),COH_FRESH_OWNER_OUTPUT_CHARACTER_ALIAS)||coh_fresh_source_owner_failed((!character_IsInitialized(entity->pchar)),COH_FRESH_OWNER_CHARACTER_UNINITIALIZED)||coh_fresh_source_owner_failed((character->entParent!=entity),COH_FRESH_OWNER_CHARACTER_PARENT))return 0;
 if(coh_fresh_source_owner_failed((link->type!=NLT_UDP),COH_FRESH_OWNER_LINK_TYPE)||coh_fresh_source_owner_failed((!link->connected),COH_FRESH_OWNER_LINK_NOT_CONNECTED)||coh_fresh_source_owner_failed((link->pending),COH_FRESH_OWNER_LINK_PENDING)||coh_fresh_source_owner_failed((link->connecting),COH_FRESH_OWNER_LINK_CONNECTING)||coh_fresh_source_owner_failed((link->disconnected),COH_FRESH_OWNER_LINK_DISCONNECTED)||coh_fresh_source_owner_failed((link->destroyed),COH_FRESH_OWNER_LINK_DESTROYED)||coh_fresh_source_owner_failed((link->removedFromMasterList),COH_FRESH_OWNER_LINK_REMOVED)||coh_fresh_source_owner_failed((link->protocolVersion>5u),COH_FRESH_OWNER_LINK_PROTOCOL)||coh_fresh_source_owner_failed(((int)client->ready<(int)CLIENTSTATE_NOT_READY),COH_FRESH_OWNER_CLIENT_STATE_LOW)||coh_fresh_source_owner_failed(((int)client->ready>(int)CLIENTSTATE_RE_REQALLENTS),COH_FRESH_OWNER_CLIENT_STATE_HIGH))return 0;
 for(i=0;i<(unsigned)net_links.links->size;i++){
  const NetLink*entry=(const NetLink*)net_links.links->storage[i];
  if(coh_fresh_source_owner_failed((!entry),COH_FRESH_OWNER_LIST_ENTRY_ABSENT)||coh_fresh_source_owner_failed((!coh_source_owner_disjoint(out,sizeof(*out),entry,sizeof(*entry))),COH_FRESH_OWNER_OUTPUT_LIST_ENTRY_ALIAS))return 0;
  if(entry==link){slot=i;incidence++;}if(entry->userData==client)client_incidence++;
 }
 if(coh_fresh_source_owner_failed((incidence!=1u),COH_FRESH_OWNER_LINK_INCIDENCE)||coh_fresh_source_owner_failed((client_incidence!=1u),COH_FRESH_OWNER_CLIENT_INCIDENCE))return 0;
 memset(&candidate,0,sizeof(candidate));memset(words,0,sizeof(words));
 words[0]=1;words[1]=COH_SOURCE_GROUPS_OWNER_BYTES;words[2]=(unsigned)entity->db_id;words[3]=entity->id;words[4]=(unsigned)entity->owner;words[5]=(unsigned)client->ready;words[6]=(unsigned)entity->ready;
 words[7]=link->UID;words[8]=link->connection_id;words[9]=link->connect_id;words[10]=link->protocolVersion;words[11]=(unsigned)link->type;words[12]=(unsigned)link->opType;words[13]=(unsigned)net_links.links->size;words[14]=slot;
 words[15]=link->connected;words[16]=link->pending;words[17]=link->connecting;words[18]=link->disconnected;words[19]=link->destroyed;words[20]=link->removedFromMasterList;
 words[21]=link->compressionAllowed;words[22]=link->compressionDefault;words[23]=link->orderedAllowed;words[24]=link->orderedDefault;words[25]=link->controlCommandsSeparate;words[26]=link->cookieSend;words[27]=link->cookieEcho;
 words[28]=link->last_update_time;words[29]=(unsigned)link->last_world_id;words[30]=(unsigned)world_id;words[31]=link->last_processed_id;words[32]=link->last_recv_id;words[33]=link->last_ordered_recv_id;words[34]=client->lastSentFullUpdateID;words[35]=client->ackedFullUpdateID;words[36]=(unsigned)entity->map_id;words[37]=(unsigned)entity->static_map_id;words[38]=1;words[39]=1;words[40]=1;words[45]=entity->auth_id;
 memcpy(candidate.wire,"COHOWN01",8);for(i=0;i<46;i++){unsigned v=words[i];candidate.wire[8+i*4]=(unsigned char)v;candidate.wire[9+i*4]=(unsigned char)(v>>8);candidate.wire[10+i*4]=(unsigned char)(v>>16);candidate.wire[11+i*4]=(unsigned char)(v>>24);}
 candidate.links_scanned=(unsigned)net_links.links->size;candidate.link_slot=slot;candidate.dbid=(unsigned)entity->db_id;candidate.entity_id=entity->id;candidate.server_index=(unsigned)entity->owner;candidate.protocol_version=link->protocolVersion;*out=candidate;return 1;
}
#endif

/* NONSHIPPING: include in groupnetsend.c after original declarations.
 * Read-only PRE-worldSendUpdate observer. Exclusive owner thread, no yield,
 * lazy loads or callbacks into the engine; every output is provisional.
 * Records do not establish a catalog generation or live receive authority.
 */
#ifndef COH_SOURCE_GROUPS_ELIGIBILITY_INCLUDED
#define COH_SOURCE_GROUPS_ELIGIBILITY_INCLUDED
#define COH_GROUPS_ELIGIBILITY_MAX_FILES 4096u
#define COH_GROUPS_ELIGIBILITY_MAX_DEFS 65536u
#define COH_GROUPS_ELIGIBILITY_MAX_REFS 65536u
/* Fixed 64-byte LE records; kind1 begin,2 file,3 definition,4 root,5 end.
 * No native pointers, struct padding, inferred saved state or default flags. */
typedef int (*CohGroupsEligibilityOutput)(void*,const unsigned char*,unsigned);
typedef struct CohGroupsEligibilityReport {
 unsigned records,files,slots,roots,present_files,emitted_defs,emitted_roots;
} CohGroupsEligibilityReport;
static int coh_groups_file_present(const GroupFile*f,const NetLink*l,int full)
{ return !((!full && f->mod_time<=l->last_update_time)&&!f->force_reload); }
static int coh_groups_def_present(const GroupFile*f,const GroupDef*d,const NetLink*l,int full)
{
 if(!coh_groups_file_present(f,l,full))return 0;
 if(!f->force_reload){
  if(!full&&d->mod_time<=l->last_update_time)return 0;
  if(!f->modified_on_disk&&d->file_idx&&d->saved)return 0;
 }
 return 1;
}
static int coh_groups_eligibility_record(CohGroupsEligibilityOutput fn,void*ctx,unsigned*v)
{
 unsigned char raw[64];unsigned i;
 for(i=0;i<16;i++){raw[i*4]=(unsigned char)v[i];raw[i*4+1]=(unsigned char)(v[i]>>8);raw[i*4+2]=(unsigned char)(v[i]>>16);raw[i*4+3]=(unsigned char)(v[i]>>24);}
 return fn(ctx,raw,64)==1;
}
/* Returns 1 success,0 arguments/unsupported/limits/output refusal. out is only
 * committed after the final record succeeds; callback bytes must be discarded
 * on any failure. A successful sink still needs exact packet + same-boundary
 * catalog/runtime/run identity binding before admission. */
static int coh_source_groups_eligibility(const NetLink*link,int full_update,
 unsigned observation_id,CohGroupsEligibilityOutput fn,void*ctx,
 CohGroupsEligibilityReport*out)
{
 CohGroupsEligibilityReport r;unsigned v[16],f,i,total=0,active=0;GroupFile*file;GroupDef*d;DefTracker*ref;
 if(!link||!fn||!out||!observation_id||(full_update!=0&&full_update!=1)||g_isBaseRaid||group_info.file_count<0||(unsigned)group_info.file_count>COH_GROUPS_ELIGIBILITY_MAX_FILES||group_info.ref_count<0||(unsigned)group_info.ref_count>COH_GROUPS_ELIGIBILITY_MAX_REFS||(group_info.file_count&&!group_info.files)||(group_info.ref_count&&!group_info.refs))return 0;
 /* Preflight every pointer and special-file branch before emitting anything.
  * Caller owns valid original structs and disjoint report/sink/context. */
 for(f=0;f<(unsigned)group_info.file_count;f++){
  file=group_info.files[f];if(!file||file->count<0||(unsigned)file->count>COH_GROUPS_ELIGIBILITY_MAX_DEFS-total||(file->count&&!file->defs)||file->base)return 0;
  total+=(unsigned)file->count;
  for(i=0;i<(unsigned)file->count;i++)if(!file->defs[i])return 0;
 }
 for(i=0;i<(unsigned)group_info.ref_count;i++){if(!group_info.refs[i])return 0;active+=(group_info.refs[i]->def!=NULL);}
 memset(&r,0,sizeof(r));memset(v,0,sizeof(v));
 v[0]=1;v[1]=1;v[2]=observation_id;v[3]=(unsigned)full_update;v[4]=link->last_update_time;v[5]=(unsigned)link->last_world_id;v[6]=(unsigned)world_id;v[7]=(unsigned)group_info.file_count;v[8]=total;v[9]=(unsigned)group_info.ref_count;v[10]=active;v[13]=(unsigned)(link->last_world_id!=world_id);
 if(!coh_groups_eligibility_record(fn,ctx,v))return 0;r.records++;
 /* Source send order: files1..N-1 then0. Preserve slot order incl inactive. */
 for(f=0;f<(unsigned)group_info.file_count;f++){
  unsigned index=(f+1u)%(unsigned)group_info.file_count;
  file=group_info.files[index];memset(v,0,sizeof(v));v[0]=2;v[1]=index;v[2]=file->mod_time;v[3]=(unsigned)file->force_reload;v[4]=(unsigned)file->modified_on_disk;v[5]=(unsigned)file->count;v[6]=file->bounds_checksum;v[7]=(unsigned)coh_groups_file_present(file,link,full_update);
  if(!coh_groups_eligibility_record(fn,ctx,v))return 0;r.records++;r.files++;r.present_files+=v[7];
  for(i=0;i<(unsigned)file->count;i++){
   d=file->defs[i];memset(v,0,sizeof(v));v[0]=3;v[1]=index;v[2]=i;v[3]=(unsigned)d->id;v[4]=d->mod_time;v[5]=(unsigned)d->file_idx;v[6]=(unsigned)d->saved;v[7]=(unsigned)d->in_use;v[8]=(unsigned)coh_groups_def_present(file,d,link,full_update);
   if(!coh_groups_eligibility_record(fn,ctx,v))return 0;r.records++;r.slots++;r.emitted_defs+=v[8];
  }
 }
 for(i=0;i<(unsigned)group_info.ref_count;i++){
  ref=group_info.refs[i];memset(v,0,sizeof(v));v[0]=4;v[1]=i;v[2]=ref->mod_time;v[3]=(unsigned)(ref->def!=NULL);v[4]=(unsigned)(full_update||ref->mod_time>link->last_update_time);
  if(!coh_groups_eligibility_record(fn,ctx,v))return 0;r.records++;r.roots++;r.emitted_roots+=v[4];
 }
 memset(v,0,sizeof(v));v[0]=5;v[1]=r.records+1;v[2]=r.files;v[3]=r.slots;v[4]=r.roots;v[5]=r.present_files;v[6]=r.emitted_defs;v[7]=r.emitted_roots;
 if(!coh_groups_eligibility_record(fn,ctx,v))return 0;r.records++;*out=r;return 1;
}
#endif

/* Private diagnostic hook; include after source_groups_eligibility.inc.
 * Static state is serialized on the original worldSendUpdate owner thread.
 * Disabled unless a nonshipping caller installs all callbacks. No callback may
 * yield, load, alter source/link/packet or retain any borrowed pointer.
 */
#ifndef COH_SOURCE_GROUPS_TRANSACTION_INCLUDED
#define COH_SOURCE_GROUPS_TRANSACTION_INCLUDED
#define COH_GROUPS_TRANSACTION_MAX_BYTES (16u*1024u*1024u)
typedef struct CohGroupsTransactionHooks {
 /* begin supplies a nonzero observation identity; 0 disables this observation.
  * It must first establish owned run/source/quiescence and source-association
  * records. This seam alone cannot prove those properties. */
 unsigned (*begin)(void*,const NetLink*,int);
 CohGroupsEligibilityOutput record;
 /* finish receives exact original pre-pktSend logical packet including command.
  * No framing/compression/normalization is invented here. Partial final-byte
  * unused bits are excluded by bits. Sink must copy before returning. */
 int (*finish)(void*,unsigned,const unsigned char*,unsigned,unsigned,unsigned,
              const CohGroupsEligibilityReport*);
 void (*abort)(void*,unsigned);
 void*context;
} CohGroupsTransactionHooks;
static CohGroupsTransactionHooks coh_groups_transaction_hooks;
static unsigned coh_groups_transaction_active;
static CohGroupsEligibilityReport coh_groups_transaction_report;
static void coh_groups_transaction_begin(const NetLink*link,int full)
{
 CohGroupsTransactionHooks*h=&coh_groups_transaction_hooks;unsigned id;
 /* No reentrant invocation; do not overwrite the outer provisional capture. */
 if(coh_groups_transaction_active||!h->begin||!h->record||!h->finish||!h->abort)return;
 id=h->begin(h->context,link,full);if(!id)return;
 if(!coh_source_groups_eligibility(link,full,id,h->record,h->context,&coh_groups_transaction_report)){h->abort(h->context,id);return;}
 coh_groups_transaction_active=id;
}
static void coh_groups_transaction_finish(const Packet*pak)
{
 CohGroupsTransactionHooks*h=&coh_groups_transaction_hooks;unsigned id=coh_groups_transaction_active,bits,bytes;
 if(!id)return;coh_groups_transaction_active=0;
 bits=pak->stream.bitLength;bytes=bits/8u+(bits%8u!=0);
 if(!bits||bytes>COH_GROUPS_TRANSACTION_MAX_BYTES||!pak->stream.data||pak->stream.errorFlags||!h->finish(h->context,id,pak->stream.data,bits,pak->stream.byteAlignedMode,(unsigned)pak->compress,&coh_groups_transaction_report))h->abort(h->context,id);
}
#endif

/* UNINSTALLED NONSHIPPING raw source prefix observer. Include after the actual
 * original GroupBounds/GroupDef/GroupFile types and catalog exporter. The caller
 * holds exclusive group ownership and the real model-quiet lease continuously
 * with owner/eligibility/packet observations. Callbacks copy only, never yield,
 * load/mutate/reenter. No native layout or generation authority is inferred. */
#ifndef COH_SOURCE_PUBLIC_BOUNDS_INCLUDED
#define COH_SOURCE_PUBLIC_BOUNDS_INCLUDED
#include <stddef.h>
#define COH_RAW_BOUNDS_MAX_BYTES (32u*1024u*1024u)
#define COH_RAW_BOUNDS_HEADER_BYTES 96u
#define COH_RAW_BOUNDS_BYTES 60u
#define COH_RAW_LAYOUT_ASSERT(n,test) typedef char CohRawLayout_##n[(test)?1:-1]
COH_RAW_LAYOUT_ASSERT(float4,sizeof(F32)==4);
COH_RAW_LAYOUT_ASSERT(int4,sizeof(int)==4);
COH_RAW_LAYOUT_ASSERT(bounds60,sizeof(GroupBounds)==60);
#define COH_RAW_PREFIX(n,at) COH_RAW_LAYOUT_ASSERT(bounds_##n,offsetof(GroupBounds,n)==at);COH_RAW_LAYOUT_ASSERT(def_##n,offsetof(GroupDef,n)==at)
COH_RAW_PREFIX(min,0);COH_RAW_PREFIX(max,12);COH_RAW_PREFIX(mid,24);
COH_RAW_PREFIX(vis_dist,36);COH_RAW_PREFIX(radius,40);COH_RAW_PREFIX(lod_scale,44);
COH_RAW_PREFIX(shadow_dist,48);COH_RAW_PREFIX(recursive_count,52);
#undef COH_RAW_PREFIX
#undef COH_RAW_LAYOUT_ASSERT
static unsigned coh_raw_bounds_u32(const unsigned char*p)
{return(unsigned)p[0]|(unsigned)p[1]<<8|(unsigned)p[2]<<16|(unsigned)p[3]<<24;}
typedef struct CohSourcePublicBoundsReport {unsigned status,total_bytes,emitted_bytes,files,slots,public_rows;} CohSourcePublicBoundsReport;
static int coh_source_public_bounds_export(CohSourceCatalogOutputFn output,void*context,
 const unsigned char catalog_header[48],const CohSourceCatalogExportReport*catalog,
 CohSourcePublicBoundsReport*report)
{
 unsigned pass,f,i,total=96,slots=0,public_rows=0,emitted=0,one=1;
 unsigned char header[96],fields[32];GroupFile*file;GroupDef*d;unsigned name,selected,allocated,active,n;
 if(!report)return COH_SOURCE_CATALOG_ARGUMENT;
 memset(report,0,sizeof(*report));
 if(!output||!catalog_header||!catalog||catalog->status||catalog->total_bytes!=catalog->emitted_bytes||((unsigned char*)&one)[0]!=1u)return report->status=COH_SOURCE_CATALOG_ARGUMENT;
 if(memcmp(catalog_header,"COHCAT01",8)||coh_raw_bounds_u32(catalog_header+8)!=1||coh_raw_bounds_u32(catalog_header+12)!=48||coh_raw_bounds_u32(catalog_header+16)!=catalog->total_bytes||!coh_raw_bounds_u32(catalog_header+20)||group_info.file_count<0||(unsigned)group_info.file_count>COH_SOURCE_CATALOG_MAX_FILES||catalog->files!=(unsigned)group_info.file_count||coh_raw_bounds_u32(catalog_header+24)!=catalog->files||(group_info.file_count&&!group_info.files))return report->status=COH_SOURCE_CATALOG_SOURCE;
 for(pass=0;pass<2;pass++){
  unsigned pass_slots=0,pass_public=0,pass_bytes=96;
  for(f=0;f<(unsigned)group_info.file_count;f++){
   file=group_info.files[f];
   if(!file||file->idx!=(int)f||file->count<0||(unsigned)file->count>COH_SOURCE_CATALOG_MAX_SLOTS-pass_slots||(file->count&&!file->defs))return report->status=COH_SOURCE_CATALOG_SOURCE;
   name=coh_source_catalog_name_bytes(file->fullname);if(!name)return report->status=COH_SOURCE_CATALOG_SOURCE;
   if(24u+name>COH_RAW_BOUNDS_MAX_BYTES-pass_bytes)return report->status=COH_SOURCE_CATALOG_LIMIT;
   pass_bytes+=24u+name;
   if(pass){memset(fields,0,24);coh_source_catalog_put_u32(fields,f);coh_source_catalog_put_u32(fields+4,(unsigned)file->idx);coh_source_catalog_put_u32(fields+8,file->bounds_checksum);coh_source_catalog_put_u32(fields+12,(unsigned)file->count);coh_source_catalog_put_u32(fields+16,name);if(output(context,fields,24)!=1||output(context,(const unsigned char*)file->fullname,name)!=1)return report->status=COH_SOURCE_CATALOG_OUTPUT;emitted+=24u+name;}
   for(i=0;i<(unsigned)file->count;i++){
    d=file->defs[i];allocated=d!=NULL;active=d&&d->in_use;name=0;selected=0;
    if(d&&(d->id!=(int)i||(active&&d->file!=file)))return report->status=COH_SOURCE_CATALOG_SOURCE;
    if(active){name=coh_source_catalog_name_bytes(d->name);if(!name)return report->status=COH_SOURCE_CATALOG_SOURCE;}
    selected=(unsigned)(groupIsPublic(d)!=0);if(selected&&!active)return report->status=COH_SOURCE_CATALOG_SOURCE;
    n=32u+name+(selected?60u:0u);if(n>COH_RAW_BOUNDS_MAX_BYTES-pass_bytes)return report->status=COH_SOURCE_CATALOG_LIMIT;pass_bytes+=n;pass_public+=selected;pass_slots++;
    if(pass){memset(fields,0,sizeof(fields));coh_source_catalog_put_u32(fields,i);coh_source_catalog_put_u32(fields+4,d?(unsigned)d->id:0xffffffffu);coh_source_catalog_put_u32(fields+8,allocated);coh_source_catalog_put_u32(fields+12,active);coh_source_catalog_put_u32(fields+16,selected);coh_source_catalog_put_u32(fields+20,name);coh_source_catalog_put_u32(fields+24,selected?60u:0u);
     if(output(context,fields,32)!=1||(name&&output(context,(const unsigned char*)d->name,name)!=1)||(selected&&output(context,(const unsigned char*)d->min,sizeof(GroupBounds))!=1))return report->status=COH_SOURCE_CATALOG_OUTPUT;emitted+=n;
    }
   }
  }
  if(!pass){total=pass_bytes;slots=pass_slots;public_rows=pass_public;if(slots!=catalog->slots)return report->status=COH_SOURCE_CATALOG_CHANGED;
   memset(header,0,sizeof(header));memcpy(header,"COHRBW01",8);coh_source_catalog_put_u32(header+8,1);coh_source_catalog_put_u32(header+12,96);coh_source_catalog_put_u32(header+16,total);coh_source_catalog_put_u32(header+20,coh_raw_bounds_u32(catalog_header+20));coh_source_catalog_put_u32(header+24,1);coh_source_catalog_put_u32(header+28,60);memcpy(header+32,catalog_header,48);coh_source_catalog_put_u32(header+80,catalog->files);coh_source_catalog_put_u32(header+84,slots);coh_source_catalog_put_u32(header+88,public_rows);
   if(output(context,header,sizeof(header))!=1)return report->status=COH_SOURCE_CATALOG_OUTPUT;emitted=96;
  }else if(pass_bytes!=total||pass_slots!=slots||pass_public!=public_rows)return report->status=COH_SOURCE_CATALOG_CHANGED;
 }
 report->total_bytes=total;report->emitted_bytes=emitted;report->files=catalog->files;report->slots=slots;report->public_rows=public_rows;return 0;
}
#endif

/* NONSHIPPING caller preparation only; no hook installation or sink.
 * Include after real owner, exporters, eligibility and transaction helpers.
 * Original exclusive link/client/entity/group/model owner thread, completed
 * loader init, disabled folder callbacks, no engine callbacks/lazy loads/yield
 * throughout begin -> original worldSendUpdate -> finish/abort are prerequisites.
 * The real quiet functions must be linked from guarded original anim.c.
 */
#ifndef COH_SOURCE_GROUPS_BOUNDARY_INCLUDED
#define COH_SOURCE_GROUPS_BOUNDARY_INCLUDED
#define COH_GROUPS_BOUNDARY_MAX_BYTES (128u*1024u*1024u)
int coh_resource_quiescence_begin(void);
int coh_resource_quiescence_end(void);
extern int folder_cache_update_enable,folder_cache_manual_callback_check;
typedef struct CohGroupsBoundarySink {
 /* Local monotonic id only: sink must bind actual fresh run/source receipt and
  * use private provisional outputs. It is NOT a runtime generation token. */
 int (*open)(void*,unsigned);
 /* kind 1 owner,2 catalog,3 runtime,4 resources,5 eligibility,6 raw public bounds; copy synchronously. */
 int (*write)(void*,unsigned,unsigned,const unsigned char*,unsigned);
 int (*packet)(void*,unsigned,const unsigned char*,unsigned,unsigned,unsigned,
               const CohGroupsEligibilityReport*,const CohSourceCatalogExportReport*,
               const CohSourceSnapshotReport*,const CohSourceResourceReport*,const CohSourcePublicBoundsReport*);
 /* Commit only after all data and actual quiet-release success. */
 int (*commit)(void*,unsigned);
 void (*abort)(void*,unsigned);
 void *context;
} CohGroupsBoundarySink;
typedef struct CohGroupsBoundaryState {
 CohGroupsBoundarySink sink;
 unsigned phase,blocked,quiet,opened,id,next,bytes,kind,kind_bytes,header_present,raw_expected;
 const NetLink*link;CohSourceGroupsOwner owner;
 unsigned char header[48],scratch[COH_RESOURCE_RECORD_MAX];
 CohSourceCatalogExportReport catalog;CohSourceSnapshotReport snapshot;CohSourceResourceReport resources;CohSourcePublicBoundsReport raw_bounds;
} CohGroupsBoundaryState;
static CohGroupsBoundaryState coh_groups_boundary;
static void coh_groups_boundary_abort(void*context,unsigned id)
{
 CohGroupsBoundaryState*s=&coh_groups_boundary;(void)context;
 if(!s->phase||s->id!=id)return;
 /* Retain phase during external callbacks to prevent recursive begin/config. */
 s->phase=3;
 if(s->quiet){if(coh_resource_quiescence_end()==1)s->quiet=0;else s->blocked=1;}
 if(s->opened)s->sink.abort(s->sink.context,id);
 s->opened=0;s->link=NULL;s->phase=0;
}
static int coh_groups_boundary_write(void*context,const unsigned char*raw,unsigned n)
{
 CohGroupsBoundaryState*s=&coh_groups_boundary;unsigned cap;(void)context;
 cap=s->kind==1?COH_SOURCE_GROUPS_OWNER_BYTES:s->kind==2?COH_SOURCE_CATALOG_MAX_BYTES:s->kind==3?COH_SNAPSHOT_MAX_BYTES:s->kind==4?COH_RESOURCE_TOTAL_MAX:s->kind==6?COH_RAW_BOUNDS_MAX_BYTES:64u*(COH_GROUPS_ELIGIBILITY_MAX_FILES+COH_GROUPS_ELIGIBILITY_MAX_DEFS+COH_GROUPS_ELIGIBILITY_MAX_REFS+2u);
 if(!s->phase||!s->opened||!s->quiet||!raw||!n||n>cap-s->kind_bytes||n>COH_GROUPS_BOUNDARY_MAX_BYTES-s->bytes)return 0;
 if(s->kind==2&&!s->kind_bytes){if(n!=sizeof(s->header))return 0;memcpy(s->header,raw,n);s->header_present=1;}
 /* Raw supplier preflights its complete ledger before this first header.
  * Charge the entire candidate output against remaining transaction capacity
  * BEFORE invoking any raw sink callback; no post-hoc admission. */
 if(s->kind==6&&!s->kind_bytes){
  unsigned bytes;
  if(n!=96u||memcmp(raw,"COHRBW01",8)||coh_raw_bounds_u32(raw+8)!=1u||coh_raw_bounds_u32(raw+12)!=96u||memcmp(raw+32,s->header,48))return 0;
  bytes=coh_raw_bounds_u32(raw+16);
  if(bytes<96u||bytes>COH_RAW_BOUNDS_MAX_BYTES||bytes>COH_GROUPS_BOUNDARY_MAX_BYTES-s->bytes)return 0;
  s->raw_expected=bytes;
 }
 if(s->kind==6&&(!s->raw_expected||s->kind_bytes>s->raw_expected||n>s->raw_expected-s->kind_bytes))return 0;
 if(s->sink.write(s->sink.context,s->id,s->kind,raw,n)!=1)return 0;
 s->kind_bytes+=n;s->bytes+=n;return 1;
}
static unsigned coh_groups_boundary_begin(void*context,const NetLink*link,int full)
{
 CohGroupsBoundaryState*s=&coh_groups_boundary;int status;(void)context;
 if(s->phase||s->blocked||full!=1||s->next==0xffffffffu||folder_cache_update_enable||!folder_cache_manual_callback_check)return 0;
 s->phase=1;s->id=++s->next;s->link=link;s->opened=s->quiet=s->bytes=s->kind_bytes=s->header_present=s->raw_expected=0;
 memset(&s->catalog,0,sizeof(s->catalog));memset(&s->snapshot,0,sizeof(s->snapshot));memset(&s->resources,0,sizeof(s->resources));memset(&s->raw_bounds,0,sizeof(s->raw_bounds));
 coh_fresh_source_probe_step(COH_FRESH_STAGE_QUIET);
 status=coh_resource_quiescence_begin();if(status!=1)goto fail;s->quiet=1;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_OWNER);
 if(!coh_source_groups_prepare_owner(link,&s->owner))goto fail;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_OPEN);
 s->opened=1;if(s->sink.open(s->sink.context,s->id)!=1)goto fail;
 s->kind=1;if(!coh_groups_boundary_write(s,s->owner.wire,sizeof(s->owner.wire)))goto fail;
 s->kind=2;s->kind_bytes=0;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_CATALOG);
 status=coh_source_catalog_export(coh_groups_boundary_write,s,s->id,&s->catalog);
 if(status||s->catalog.status||!s->header_present||s->catalog.total_bytes!=s->kind_bytes||s->catalog.emitted_bytes!=s->kind_bytes)goto fail;
 s->kind=3;s->kind_bytes=0;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_RUNTIME);
 status=coh_source_runtime_snapshot_export(coh_groups_boundary_write,s,s->header,&s->catalog,&s->snapshot);
 if(status||s->snapshot.status||s->snapshot.total_bytes!=s->kind_bytes||s->snapshot.emitted_bytes!=s->kind_bytes)goto fail;
 s->kind=4;s->kind_bytes=0;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_RESOURCES);
 status=coh_source_resources_export(coh_groups_boundary_write,s,s->header,&s->catalog,s->scratch,sizeof(s->scratch),&s->resources);
 if(status||s->resources.status||s->resources.total_bytes!=s->kind_bytes||s->resources.emitted_bytes!=s->kind_bytes||s->resources.client_materials_available||s->resources.client_lods_available)goto fail;
 s->kind=6;s->kind_bytes=0;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_BOUNDS);
 status=coh_source_public_bounds_export(coh_groups_boundary_write,s,s->header,&s->catalog,&s->raw_bounds);
 if(status||s->raw_bounds.status||!s->raw_expected||s->raw_bounds.total_bytes!=s->raw_expected||s->raw_bounds.emitted_bytes!=s->kind_bytes||s->kind_bytes!=s->raw_expected||s->raw_bounds.files!=s->catalog.files||s->raw_bounds.slots!=s->catalog.slots)goto fail;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_ELIGIBILITY);
 s->kind=5;s->kind_bytes=0;s->phase=2;return s->id;
fail:coh_groups_boundary_abort(s,s->id);return 0;
}
static int coh_groups_boundary_record(void*context,const unsigned char*raw,unsigned n)
{(void)context;return coh_groups_boundary.phase==2&&coh_groups_boundary.kind==5&&n==64u?coh_groups_boundary_write(&coh_groups_boundary,raw,n):0;}
static int coh_groups_boundary_finish(void*context,unsigned id,const unsigned char*raw,unsigned bits,unsigned aligned,unsigned compress,const CohGroupsEligibilityReport*r)
{
 CohGroupsBoundaryState*s=&coh_groups_boundary;CohSourceGroupsOwner current;unsigned n=bits/8u+(bits%8u!=0);(void)context;
 if(s->phase!=2||s->id!=id||!s->quiet||!raw||!bits||n>COH_GROUPS_TRANSACTION_MAX_BYTES||n>COH_GROUPS_BOUNDARY_MAX_BYTES-s->bytes||!r||r->records>0xffffffffu/64u||r->records*64u!=s->kind_bytes||!coh_source_groups_prepare_owner(s->link,&current))return 0;
 /* Original worldSendUpdate changes link timestamps/world id and force_reload.
  * Compare exact owner wire except those two documented timestamp/world words. */
 memcpy(current.wire+8u+28u*4u,s->owner.wire+8u+28u*4u,8u);
 if(memcmp(current.wire,s->owner.wire,sizeof(current.wire)))return 0;
 s->phase=3;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_PACKET);
 if(s->sink.packet(s->sink.context,id,raw,bits,aligned,compress,r,&s->catalog,&s->snapshot,&s->resources,&s->raw_bounds)!=1)return 0;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_QUIET_RELEASE);
 if(coh_resource_quiescence_end()!=1){s->blocked=1;return 0;}s->quiet=0;
 coh_fresh_source_probe_step(COH_FRESH_STAGE_COMMIT);
 if(s->sink.commit(s->sink.context,id)!=1)return 0;
 s->opened=0;s->link=NULL;s->phase=0;return 1;
}
/* Only prepares a hook value. Caller installation remains absent. Config/sink,
 * outputs and all engine storage must be disjoint; callbacks cannot reenter.
 * No callbacks or observation occur here. Existing installed hooks are untouched. */
static int coh_groups_boundary_prepare(const CohGroupsBoundarySink*sink,CohGroupsTransactionHooks*out)
{
 CohGroupsTransactionHooks h;
 if(!sink||!out||coh_groups_boundary.phase||coh_groups_boundary.blocked||!sink->open||!sink->write||!sink->packet||!sink->commit||!sink->abort)return 0;
 memset(&h,0,sizeof(h));h.begin=coh_groups_boundary_begin;h.record=coh_groups_boundary_record;h.finish=coh_groups_boundary_finish;h.abort=coh_groups_boundary_abort;h.context=&coh_groups_boundary;
 coh_groups_boundary.sink=*sink;*out=h;return 1;
}
#endif

void worldSendUpdate(NetLink *link,int full_update)
{
    int            i,k;
    U32            mod_time=0;
    DefTracker    *ref;
    Packet        *pak;
    coh_groups_transaction_begin(link,full_update);
    
//assert(heapValidateAll());
#if 0
    int timer = timerAlloc();
    timerStart(timer);
#endif
    pak = pktCreate();
    if (full_update)
        pktSetCompression(pak,1);
    pktSendBitsPack(pak,1,SERVER_GROUPS);

    pktSendBitsPack(pak,1,journalUndosRemaining());
    pktSendBitsPack(pak,1,journalRedosRemaining());

    if (link->last_world_id != world_id)
    {
        const MapSpec *spec;
        StaticMapInfo *info;

        link->last_world_id = world_id;
        pktSendBits(pak,1,1);
        pktSendBits(pak,2, db_state.is_endgame_raid ? 2 : (!db_state.is_static_map && !(db_state.local_server && !g_activemission)) );
        pktSendBitsPack(pak,1,db_state.instance_id);
        pktSendBitsPack( pak,1, server_state.doNotAutoGroup );//MW added
        pktSendBitsPack(pak, 1, db_state.base_map_id);

        STATIC_INFUNC_ASSERT(MAP_TEAM_COUNT <= 8);

        spec = MapSpecFromMapId(db_state.base_map_id);
        info = staticMapInfoFind(db_state.base_map_id);

        if (db_state.is_static_map && spec && info)
        {
            pktSendBitsAuto(pak, info->introZone);
            pktSendBitsPack(pak, 3, spec->teamArea);
        }
        else
        {
 			if (g_MapIsTutorial)
			{
				// Mark mission maps within tutorials as being IntroZone 4
				pktSendBitsAuto(pak, 4);
            }
            else
            {
                pktSendBitsAuto(pak, 0);
            }
            pktSendBitsPack(pak, 3, MAP_TEAM_EVERYBODY);
        }

        sendLoadScreenPages(pak);

        if(!group_info.loadscreen || !group_info.loadscreen[0])
            pktSendString(pak,0);
        else
            pktSendString(pak,group_info.loadscreen);

        if (!group_info.files)
            pktSendString(pak,0);
        else
            pktSendString(pak,group_info.files[0] ? group_info.files[0]->fullname : 0);
    }
    else
        pktSendBits(pak,1,0);

    pktSendBits(pak, 1, (beaconGetReadFileVersion()||server_state.levelEditor)? 1: 0); // Either beacons are loaded, or we explicitly told them not to load

    if (g_isBaseRaid)
    {
        pktSendBitsPack(pak,1,1);
        sendGroupFile(group_info.files[0],link,full_update,pak,&mod_time);
    }
    else
    {
        pktSendBitsPack(pak,1,group_info.file_count);
        for(k=1;k<group_info.file_count;k++)
            sendGroupFile(group_info.files[k],link,full_update,pak,&mod_time);
        if (group_info.file_count)
            sendGroupFile(group_info.files[0],link,full_update,pak,&mod_time);
    }

    for(i=0;i<group_info.ref_count;i++)
    {
        ref = group_info.refs[i];
        if (!full_update && ref->mod_time <= link->last_update_time)
            continue;
        if (ref->mod_time > mod_time)
            mod_time = ref->mod_time;
        pktSendBitsPack(pak,1,i);
        if (ref->def)
        {
            pktSendString(pak,ref->def->name);
            sendMat4(pak,ref->mat);
        }
        else
        {
            pktSendString(pak,0);
        }
    }
    if (mod_time)
    {
        link->last_update_time = mod_time;
    }
    pktSendBitsPack(pak,1,-1);

    pktSendBitsPack(pak, 1, group_info.file_count);
    pktSendBitsPack(pak, 1, groupInfoRefCount());
    pktSendBits(pak, 32, groupInfoCrcDefs());
    pktSendBits(pak, 32, groupInfoCrcRefs());

    
    errorSetVerboseLevel(10);
    verbose_printf("world update: %d bytes\n",pktGetSize(pak));
    errorSetVerboseLevel(0);

#if 0
    {
    U8        *dst;
    int        dstlen;

        printf("%d tricks %d soundshadow %d child %d total\n",trick_count,soundshadow_count,child_count,def_count);
        dstlen = pktGetSize(pak) * 2 + 16;
        dst = malloc(dstlen);
        printf("timer elapsed: %f\n",timerElapsed(timer));
        compress2(dst,&dstlen,pak->stream.data,pktGetSize(pak)+1,5);
        printf("timer elapsed: %f\n",timerElapsed(timer));
        timerFree(timer);
        printf("compressed: %d\n",dstlen);
    }
#endif

    coh_groups_transaction_finish(pak);
    //sendAllBounds(pak);
    pak->reliable=1;
    pktSend(&pak,link);
//assert(heapValidateAll());
}

// cleaned up world_name, can be used with ErrorFilenamef
char* currentMapFile(void)
{
    char* pos;
    static char buffer[MAX_PATH];
    strcpy(buffer, world_name);
    forwardSlashes(buffer);

    // make relative
    pos = strstr(buffer, "data/");
    if (pos)
    {
        pos += 5;
        memmove(buffer, pos, strlen(pos)+1);
    }
    return buffer;
}

void markDynamicDefChange(GroupDef *def) {
    if (eaFind(&pendingDynamicDefChanges, def) == -1)
        eaPush(&pendingDynamicDefChanges, def);
}

void sendDynamicDefChanges(NetLink *link) {
    int i;
    int numDefs = eaSize(&pendingDynamicDefChanges);

    if (numDefs > 0) {
        Packet *pak = pktCreateEx(link, SERVER_DYNAMIC_DEFS);
        pktSendBitsPack(pak, 1, numDefs);

        for (i = 0; i < numDefs; ++i) {
            pktSendString(pak, pendingDynamicDefChanges[i]->name);
            pktSendBitsPack(pak, 1, pendingDynamicDefChanges[i]->hideForGameplay);
        }

        pktSend(&pak, link);
    }
}

void clearDynamicDefChanges() {
    eaDestroy(&pendingDynamicDefChanges);
}

/*
#if 0
        for(i=0;i<file->count;i++)
        {
            if (file->defs[i])
            {
                pktSendString(pak,file->defs[i]->name);
                pktSendF32(pak,file->defs[i]->vis_dist);
                pktSendF32(pak,file->defs[i]->radius);
                pktSendF32(pak,file->defs[i]->lod_scale);
                pktSendF32(pak,file->defs[i]->shadow_dist);
                pktSendVec3(pak,file->defs[i]->min);
                pktSendVec3(pak,file->defs[i]->max);
                pktSendVec3(pak,file->defs[i]->mid);
            }
        }
        pktSendString(pak,0);
    }

    for(k=0;k<group_info.file_count;k++)
    {
        GroupFile    *file = group_info.files[k];

        for(i=0;i<file->count;i++)
        {
            def = group_info.files[k]->defs[i];
            if (!full_update && def->mod_time <= link->last_update_time)
                continue;
            if (def->file_idx && def->saved)
                continue;
            if (def->mod_time > mod_time)
                mod_time = def->mod_time;
            pktSendBitsPack(pak,1,k);
            sendDef(pak,def);
        }
    }
    pktSendBitsPack(pak,1,-1);
#endif
*/

/* NONSHIPPING opt-in actual source transaction sink. */
#include "coh_source_catalog_sink.inc"
#include "coh_source_groups_capture_sink.inc"

/* NEW explicit fresh disposable callback-sealed diagnostic profile. */
#include "coh_fresh_source_profile.inc"
