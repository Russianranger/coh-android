# Complete Details geometry group projection

The existing Salvage/Details and BaseDetail inventory owners retain definition
names and ID identity. They do not provide the six geometry group names needed
by a future base scene resolver. This standalone bounded owner reads every field
of the complete original Details Parse6 body, then copies its six group names
with the original resource suffix and surface preprocessing. It neither changes
those accepted owners nor binds a current character/world generation.

Original indirect-single strings turn empty serialized values into NULL.
Case-insensitive `_f`, `_w` and `_c` roots generate missing variants; animated
objects use the powered unpowered suffix; mounted destruction inserts `_MNT`.
Explicit nonempty variants remain exact, including the `dim` sentinel. A leading
`*` strips the root escape and suppresses suffix expansion. Surface inference
precedes this escape. Source U8 flags truncate serialized words before use.
All complete 47 persisted fields, record lengths, file ledger and final end are
validated. Arrays and unrelated fields remain opaque; gameplay/evaluation,
CLIENT unused-field pruning, pre/post/finalizer semantics beyond this resource
projection, group loading, material creation and actor publication do not run.

The copied owner retains complete input SHA256 and caller-admitted provenance.
The caller must independently admit those identities; an arbitrary expected hash
cannot authenticate a resource archive. Row ordinals preserve full Details order
including duplicate names; no name hash, inventory ID or geometry membership is
invented. Getters return borrowed immutable owner slices. Empty fields return
NOT_FOUND. `dim` remains explicit data and is not treated as a group to load.

Native refusal policies are 4096 rows, 512KiB complete input and copied text,
8MiB total read/comparison/poll work, 8192 array elements, source Pascal strings
under 12000 bytes, ASCII definition keys under 128 bytes, resource names and
generated variants under 1024 bytes. Missing root with surface=-1 refuses safely
because the original preprocess dereferences that root. The complete 16MiB
aggregate charges input/config/provider/control/contexts/output/workspace,
declared callback scratch/stack, 16KiB native stack and caller-retained old
owners before callbacks. No heap allocation occurs. Output commits only after
full parsing, preprocessing, input hash and final cancellation. Valid callback
errors retain their first status; out-of-domain digest errors become COH_INVALID. Scratch may be
partial after refusal. All source/provider leases can retire after success.
These are child policies and caller accounting, not process/RSS/GPU or global
96MiB fit claims.

Run only the new checker:
`python3 native-android/engine/basedetail-resources/check_resources.py --details-bin DETAILS --output NEW_DIR`.
It admits the exact retained complete original 401216-byte Details body with
SHA256 `11e5104e0210fa5cbbc910932e5df461a34853e9a30d43f890d31510cdf2ce28`.
It compares canonical complete projected rows with the whole original Parse6
reader and whole original shared preprocessing function on explicit bounded host
storage. The original host adapter applies the original empty indirect-string
policy; CLIENT pruning is compiled out and original stash/allocator/ABI/geometry
are not reproduced. Release/ASan/UBSan target only the new module, test and
necessary immutable headers; old qualifier entrypoints do not run. The original
comparison is unsanitized; native leak detection is disabled. Source bytes,
fixture and binaries are bracketed. No Thor/Android/current CLIENT/world
acceptance or APK change follows from host qualification.
