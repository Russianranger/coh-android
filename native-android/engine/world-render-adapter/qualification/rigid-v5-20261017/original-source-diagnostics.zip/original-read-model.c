typedef unsigned char U8;typedef unsigned int U32;typedef short S16;typedef float F32;typedef float Vec3[3];typedef unsigned int uintptr_t;typedef int intptr_t;typedef unsigned int size_t;
typedef struct VBO VBO;typedef struct BoneInfo BoneInfo;typedef struct TrickNode TrickNode;typedef struct CTri CTri;typedef struct AltPivotInfo AltPivotInfo;typedef struct ModelExtra ModelExtra;typedef struct GeoLoadData GeoLoadData;typedef struct PolyCell PolyCell;typedef struct TexID TexID;
static void die(int value){__asm__ volatile("int $0x80"::"a"(1),"b"(value):"memory");for(;;){}}
#define assert(x) do{if(!(x))die(90);}while(0)
#define CLIENT 1
static void*memcpy(void*d,const void*s,size_t n){U8*a=d;const U8*b=s;for(size_t i=0;i<n;i++)a[i]=b[i];return d;}
static void*memset(void*d,int v,size_t n){U8*a=d;for(size_t i=0;i<n;i++)a[i]=(U8)v;return d;}
#define copyVec3(a,b) memcpy(b,a,12)
#define setVec3(a,x,y,z) do{(a)[0]=x;(a)[1]=y;(a)[2]=z;}while(0)
typedef struct PackData
{
    int        packsize;
    U32        unpacksize;
    U8        *data;
} PackData;
typedef struct
{
    PolyCell    *cell;
    Vec3        pos;
    F32            size;
    F32            inv_size;
    int            tag;
    int            num_bits;
} PolyGrid;
typedef struct
{
    PackData        tris;
    PackData        verts;
    PackData        norms;
    PackData        sts;
    PackData        weights;
    PackData        matidxs;
    PackData        grid;
} PackBlockOnDisk;

typedef struct ModelFormatOnDisk_v2 // Do not change this structure
{
    // frequently used data keep in same cache block
    U32                flags;
    F32                radius;
    VBO                *vbo;
    int                tex_count;        //number of tex_idxs (sum of all tex_idx->counts == tri_count)
    S16                id;            //I am this bone 
    U8                blend_mode;
    U8                loadstate; 
    BoneInfo        *boneinfo; //if I am skinned, everything about that
    TrickNode        *trick;
    int                vert_count;
    int                tri_count;
    TexID            *tex_idx;        //array of (textures + number of tris that have it)

    // collision
    PolyGrid        grid;
    CTri            *ctris;
    int                *tags;

    // Less frequently used data
    char            *name;
    AltPivotInfo    *api;    // if I have alternate pivot points defined for fx, everything about that
    ModelExtra        *extra;    // Portals
    Vec3            scale;    // hardly used at all, but dont remove, jeremy scaling files
    Vec3            min,max;
    GeoLoadData        *gld;

    PackBlockOnDisk    pack;
} ModelFormatOnDisk_v2;
typedef struct {U32 flags;F32 radius;int tex_count;S16 id;int vert_count,tri_count,reflection_quad_count;U8 loadstate;BoneInfo*boneinfo;TexID*tex_idx;PolyGrid grid;char*name;AltPivotInfo*api;Vec3 scale,min,max,autolod_dists;struct{PackData tris,verts,norms,sts,sts3,weights,matidxs,grid,reductions,reflection_quads;}pack;} Model;
static int readModel(Model *dst, char *data, int version_num, U8 *objname_base, U8 *texidx_base)
{

    int size = 0;

    if (version_num < 3)
    {
        ModelFormatOnDisk_v2 *src = (void *)data;
        #define COPY(fld) dst->fld = src->fld
            COPY(flags);
            COPY(radius);
            COPY(tex_count);
            COPY(id);
            COPY(loadstate);
            COPY(boneinfo);
            assert(!src->trick);
            COPY(vert_count);
            COPY(tri_count);
            dst->tex_idx = (TexID*)(texidx_base + (uintptr_t)src->tex_idx);

            COPY(grid);
            assert(!src->ctris);
            assert(!src->tags);

            dst->name = objname_base + (uintptr_t)src->name;
            COPY(api);
            assert(!src->extra);    // Portals
            copyVec3(src->scale, dst->scale);
            copyVec3(src->min, dst->min);
            copyVec3(src->max, dst->max);

            COPY(pack.tris);
            COPY(pack.verts);
            COPY(pack.norms);
            COPY(pack.sts);
            memset(&dst->pack.sts3, 0, sizeof(dst->pack.sts3));
            COPY(pack.weights);
            COPY(pack.matidxs);
            COPY(pack.grid);
        #undef COPY

        size = sizeof(*src);
    }
    else
    {
        #define COPY(fld,bytes) { memcpy(&(dst->fld), data, bytes); data += bytes; }
        #define COPY2(fld,bytes) { memcpy((dst->fld), data, bytes); data += bytes; }

            memcpy(&size, data, 4); data += 4;
            
            COPY(radius, 4);
            COPY(tex_count, 4);
            COPY(boneinfo, 4);
            COPY(vert_count, 4);
            COPY(tri_count, 4);
            if (version_num >= 8)
            {
                COPY(reflection_quad_count, 4);
            }
            COPY(tex_idx, 4);
            dst->tex_idx = (TexID*)(texidx_base + (intptr_t)dst->tex_idx);
            COPY(grid, sizeof(PolyGrid));
            COPY(name, 4);
            dst->name = objname_base + (intptr_t)dst->name;
            COPY(api, 4);
            COPY2(scale, sizeof(Vec3));
            COPY2(min, sizeof(Vec3));
            COPY2(max, sizeof(Vec3));
            COPY(pack.tris, sizeof(PackData));
            COPY(pack.verts, sizeof(PackData));
            COPY(pack.norms, sizeof(PackData));
            COPY(pack.sts, sizeof(PackData));
            COPY(pack.sts3, sizeof(PackData));
            COPY(pack.weights, sizeof(PackData));
            COPY(pack.matidxs, sizeof(PackData));
            COPY(pack.grid, sizeof(PackData));
            if (version_num == 4)
            {
                data += sizeof(PackData); // used to be pack.lmap_utransforms
                data += sizeof(PackData); // used to be pack.lmap_vtransforms
            }
            if (version_num >= 7)
            {
                COPY(pack.reductions, sizeof(PackData));
            }
            if (version_num >= 8)
            {
                COPY(pack.reflection_quads, sizeof(PackData));
            }
#if 0
            if (version_num < 8)
            {
                //Skip unused lightmap_size
                data += sizeof(F32);
            }
#endif
            if (version_num >= 7)
            {
#if CLIENT
                COPY(autolod_dists, sizeof(F32)*3);
#else
                data += sizeof(F32)*3;
#endif
            }
#if CLIENT
            else
            {
                setVec3(dst->autolod_dists, -1, -1, -1);
            }
#endif
            COPY(id, 2);

        #undef COPY
        #undef COPY2
    }

    assert(!dst->grid.cell);
    return size;

}
static U8 record[] __attribute__((aligned(4)))={208,0,0,0,189,27,15,65,2,0,0,0,0,0,0,0,10,0,0,0,4,0,0,0,72,0,0,0,0,0,0,0,0,0,128,192,0,0,0,0,0,0,0,0,0,0,0,65,0,0,0,62,0,0,0,0,3,0,0,0,25,1,0,0,0,0,0,0,0,0,128,63,0,0,128,63,0,0,128,63,0,0,128,192,0,0,0,0,0,0,0,0,0,0,128,64,0,0,128,64,0,0,0,65,0,0,0,0,15,0,0,0,112,7,0,0,39,0,0,0,65,0,0,0,127,7,0,0,0,0,0,0,18,0,0,0,166,7,0,0,0,0,0,0,32,0,0,0,184,7,0,0,0,0,0,0,0,0,0,0,216,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,24,0,0,0,20,0,0,0,216,7,0,0,0,0,0,0,252,255,0,0};
static U8 names[] __attribute__((aligned(4)))={116,101,107,49,95,112,108,116,102,111,114,109,95,57,48,111,117,116,95,84,114,105,109,0,116,101,107,49,95,112,108,116,102,111,114,109,95,115,116,114,116,95,84,114,105,109,0,116,101,107,49,95,112,108,116,102,111,114,109,95,57,48,105,110,95,84,114,105,109,0,116,101,107,49,95,112,108,116,102,111,114,109,95,115,116,114,116,95,84,114,105,109,51,50,0,116,101,107,49,95,112,108,116,102,111,114,109,95,102,105,108,108,95,76,114,103,0,116,101,107,49,95,112,108,116,102,111,114,109,95,114,97,109,112,49,54,0,116,101,107,49,95,112,108,116,102,111,114,109,95,114,97,109,112,51,50,0,116,101,107,49,95,112,108,116,102,111,114,109,95,115,116,114,116,95,84,114,105,109,48,56,0,116,101,107,49,95,112,108,116,102,111,114,109,95,102,105,108,108,95,83,109,108,0,116,101,107,49,95,112,108,116,102,111,114,109,95,102,105,108,108,95,109,101,100,0,116,101,107,49,95,112,108,116,102,111,114,109,95,57,48,111,117,116,0,116,101,107,49,95,112,108,116,102,111,114,109,95,115,116,114,116,0,116,101,107,49,95,112,108,116,102,111,114,109,95,57,48,105,110,0,116,101,107,49,95,112,108,116,102,111,114,109,95,114,97,109,112,0,0};
static U8 materials[] __attribute__((aligned(4)))={1,0,8,0,1,0,2,0,1,0,8,0,1,0,4,0,2,0,2,0,3,0,2,0,2,0,2,0,3,0,2,0,2,0,2,0,1,0,4,0,2,0,2,0,2,0,2,0,1,0,8,0,4,0,4,0,1,0,2,0,2,0,2,0,1,0,8,0,5,0,6,0,3,0,2,0,2,0,2,0};

const U32 coh_layout[] __attribute__((section(".coh_layout"),used))={sizeof(ModelFormatOnDisk_v2),__builtin_offsetof(ModelFormatOnDisk_v2,flags),__builtin_offsetof(ModelFormatOnDisk_v2,radius),__builtin_offsetof(ModelFormatOnDisk_v2,tex_count),__builtin_offsetof(ModelFormatOnDisk_v2,boneinfo),__builtin_offsetof(ModelFormatOnDisk_v2,vert_count),__builtin_offsetof(ModelFormatOnDisk_v2,tri_count),__builtin_offsetof(ModelFormatOnDisk_v2,tex_idx),__builtin_offsetof(ModelFormatOnDisk_v2,grid),__builtin_offsetof(ModelFormatOnDisk_v2,name),__builtin_offsetof(ModelFormatOnDisk_v2,api),__builtin_offsetof(ModelFormatOnDisk_v2,extra),__builtin_offsetof(ModelFormatOnDisk_v2,scale),__builtin_offsetof(ModelFormatOnDisk_v2,pack)};

void _start(void){Model dst;U32 facts[55];memset(&dst,0,sizeof(dst));int used=readModel(&dst,(char*)record,5,names,materials);
facts[0]=sizeof(ModelFormatOnDisk_v2);facts[1]=(U32)used;facts[2]=dst.flags;memcpy(facts+3,&dst.radius,4);facts[4]=dst.tex_count;facts[5]=dst.vert_count;facts[6]=dst.tri_count;facts[7]=(U32)dst.boneinfo;facts[8]=(U32)dst.api;facts[9]=(U32)dst.grid.cell;facts[10]=(U32)(dst.name-(char*)names);facts[11]=(U32)((U8*)dst.tex_idx-materials);facts[12]=(U32)dst.id;memcpy(facts+13,dst.scale,12);memcpy(facts+16,dst.min,12);memcpy(facts+19,dst.max,12);
PackData*p=&dst.pack.tris;for(unsigned i=0;i<10;i++){facts[22+i*3]=p[i].packsize;facts[23+i*3]=p[i].unpacksize;facts[24+i*3]=(U32)p[i].data;}
memcpy(facts+52,dst.autolod_dists,12);int wrote;__asm__ volatile("int $0x80":"=a"(wrote):"a"(4),"b"(1),"c"(facts),"d"(sizeof(facts)):"memory");die(wrote==(int)sizeof(facts)?0:91);}
