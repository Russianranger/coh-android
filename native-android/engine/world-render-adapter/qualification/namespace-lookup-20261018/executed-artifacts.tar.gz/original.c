#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define assert(x) ((void)0) /* original release debug assertions disabled */
#define REQUIRE(x) do{if(!(x))abort();}while(0)
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))
typedef struct{unsigned ordinal;}BasicTexture;
static BasicTexture entries[32];static const char*keys[32];static unsigned count,calls,format;static char observed[128];static void*g_basicTextures_ht;
static void strncpyt(char*d,const char*s,int n){REQUIRE(n>0&&strlen(s)<(unsigned)n);memcpy(d,s,strlen(s)+1);}
static unsigned fold(unsigned x){return x>='A'&&x<='Z'?x+32:x;}
static int same(const char*a,const char*b){while(*a&&*b){if(fold((unsigned char)*a++)!=fold((unsigned char)*b++))return 0;}return!*a&&!*b;}
static int stashFindPointer(void*t,const char*key,BasicTexture**out){(void)t;calls++;strcpy(observed,key);for(unsigned i=0;i<count;i++)if(same(key,keys[i])){*out=entries+i;return 1;}return 0;}
typedef enum TexFlags
{
    TEX_ALPHA        = 1 << 0,
    TEX_RGB8        = 1 << 1,
    TEX_COMP4        = 1 << 2,
    TEX_COMP8        = 1 << 3,
    
    TEX_TGA            = 1 << 5,
    TEX_DDS            = 1 << 6,


    TEX_CUBEMAPFACE    = 1 << 9,
    TEX_REPLACEABLE    = 1 << 10,
    TEX_BUMPMAP        = 1 << 11,

    TEX_JPEG        = 1 << 13,
} TexFlags;
static int strict_fix(const char *s,char *res, int size)
{
int        type = 0;

    if (s != res)
        strncpyt(res,s,size);

    if( strlen(res) < 4 )
        return TEX_TGA; //I guess, maybe error out?

    for(;*s;s++,res++)
    {
        //*res = tolower(*s);
    }
    if (res[-4] == '.')
    {
        if (strcmp(res-3,"tga")==0) {
            // Even though we don't load .tga files anymore, this is still used (through texFind)
            type = TEX_TGA;
        } else if (strcmp(res-3,"jpg")==0)
            type = TEX_JPEG;
        else if (strcmp(res-3,"dds")==0)
            type = TEX_DDS;
        res[-4] = 0;
    }
    //fix for files that were incorrectly named .texture instead of dds.
    else if(res[-8] == '.')
    {
        if (strcmp(res-7,"texture")==0) {
            // Even though we don't load .tga files anymore, this is still used (through texFind)
            type = TEX_DDS;
        }
        res[-8] = 0;
    }
    *res = 0;
    return type;
}
static int strict_observe(const char*s,char*r,int n){int type=strict_fix(s,r,n);format=(unsigned)type;return type;}
#define texFixName strict_observe
#define texFind strict_find
BasicTexture *texFind(const char *name)
{
    char search[128];
    BasicTexture *match = 0;

    assert(name!=(char*)0xfafafafa);

    if (!name)
        return NULL;

    assert(*(int*)name!=0xfafafafa);

    if (name[0]=='!')
        name++;

    texFixName(name, search, ARRAY_SIZE(search));
    if (!stashFindPointer(g_basicTextures_ht, search, &match)) {
        //printf("Warning: Missing texture: '%s'\n", name);
        return NULL;
    }
    return match;
}

#undef texFixName
#undef texFind
static int guarded_fix(const char *s,char *res, int size)
{
char *const res_start = res;
int        type = 0;

    if (s != res)
        strncpyt(res,s,size);

    if( strlen(res) < 4 )
        return TEX_TGA; //I guess, maybe error out?

    for(;*s;s++,res++)
    {
        //*res = tolower(*s);
    }
    if (res[-4] == '.')
    {
        if (strcmp(res-3,"tga")==0) {
            // Even though we don't load .tga files anymore, this is still used (through texFind)
            type = TEX_TGA;
        } else if (strcmp(res-3,"jpg")==0)
            type = TEX_JPEG;
        else if (strcmp(res-3,"dds")==0)
            type = TEX_DDS;
        res[-4] = 0;
    }
    //fix for files that were incorrectly named .texture instead of dds.
    else if(res - res_start >= 8 && res[-8] == '.')
    {
        if (strcmp(res-7,"texture")==0) {
            // Even though we don't load .tga files anymore, this is still used (through texFind)
            type = TEX_DDS;
        }
        res[-8] = 0;
    }
    *res = 0;
    return type;
}
static int guarded_observe(const char*s,char*r,int n){int type=guarded_fix(s,r,n);format=(unsigned)type;return type;}
#define texFixName guarded_observe
#define texFind guarded_find
BasicTexture *texFind(const char *name)
{
    char search[128];
    BasicTexture *match = 0;

    assert(name!=(char*)0xfafafafa);

    if (!name)
        return NULL;

    assert(*(int*)name!=0xfafafafa);

    if (name[0]=='!')
        name++;

    texFixName(name, search, ARRAY_SIZE(search));
    if (!stashFindPointer(g_basicTextures_ht, search, &match)) {
        //printf("Warning: Missing texture: '%s'\n", name);
        return NULL;
    }
    return match;
}

#undef texFixName
#undef texFind
void original_namespace_rows(unsigned n,const char*const*names){REQUIRE(n<=32);count=n;for(unsigned i=0;i<n;i++){keys[i]=names[i];entries[i].ordinal=i;}}
int original_namespace_lookup(const char*q,unsigned guarded,char key[128],unsigned*flags,unsigned*lookups){calls=format=0;observed[0]=0;BasicTexture*found=guarded?guarded_find(q):strict_find(q);strcpy(key,observed);*flags=format;*lookups=calls;return found?(int)found->ordinal:-1;}
