#include "coh_wr_gpu_lease.h"
int main(){CohWrGpuLease*p=nullptr;return coh_wr_gpu_lease_collect(&p)==COH_INVALID?0:1;}
