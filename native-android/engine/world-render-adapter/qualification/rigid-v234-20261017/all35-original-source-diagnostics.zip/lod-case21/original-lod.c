#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef float F32;
typedef struct AutoLOD {int flags;float max_error,lod_near,lod_far,lod_nearfade,lod_farfade;char*lod_modelname,*lod_filename;} AutoLOD;
typedef struct {AutoLOD**lods;} ModelLODInfo;
typedef struct {uint32_t count;AutoLOD*rows[6];} EA;
static AutoLOD*allocAutoLOD(void){AutoLOD*p=calloc(1,sizeof(*p));assert(p);return p;}
static void eaPush(AutoLOD***dst,AutoLOD*item){EA*p;if(!*dst){p=calloc(1,sizeof(*p));assert(p);*dst=p->rows;}p=(EA*)((char*)*dst - offsetof(EA,rows));assert(p->count<6);p->rows[p->count++]=item;}
static char*ParserAllocString(const char*s){size_t n=strlen(s)+1;char*p=malloc(n);assert(p);memcpy(p,s,n);return p;}
static void ParserFreeString(char*s){free(s);}
typedef struct AutoLODOnDisk_v5
{
    float        max_error;
    F32            lod_near, lod_far, lod_nearfade, lod_farfade;
    int            flags;
} AutoLODOnDisk_v5;

typedef struct ModelLODInfoOnDisk_v5
{
    int num_lods;
    AutoLODOnDisk_v5 lods[6];
} ModelLODInfoOnDisk_v5;
static ModelLODInfo *unpackLODInfo(char *data, int memsize, int model_count, int version_num)
{
    ModelLODInfo *lod_infos = calloc(sizeof(*lod_infos), model_count);
    int i, j, bytes_read = 0;

    if (version_num >= 6)
    {
        #define COPY(dst,bytes) { memcpy(&dst, data + bytes_read, bytes); bytes_read += bytes; }
        for (j = 0; j < model_count; j++)
        {
            ModelLODInfo *lod_info = &lod_infos[j];
            int num_lods;
            COPY(num_lods, sizeof(int));
            for (i = 0; i < num_lods; i++)
            {
                AutoLOD *lod = allocAutoLOD();
                eaPush(&lod_info->lods, lod);

                COPY(lod->flags, sizeof(int));
                COPY(lod->max_error, sizeof(float));
                COPY(lod->lod_far, sizeof(float));
                COPY(lod->lod_farfade, sizeof(float));
                COPY(lod->lod_near, sizeof(float));
                COPY(lod->lod_nearfade, sizeof(float));

                lod->lod_modelname = ParserAllocString(data + bytes_read);
                bytes_read += (int)strlen(lod->lod_modelname) + 1;
                if (!lod->lod_modelname[0])
                {
                    ParserFreeString(lod->lod_modelname);
                    lod->lod_modelname = 0;
                }

                lod->lod_filename = ParserAllocString(data + bytes_read);
                bytes_read += (int)strlen(lod->lod_filename) + 1;
                if (!lod->lod_filename[0])
                {
                    ParserFreeString(lod->lod_filename);
                    lod->lod_filename = 0;
                }
            }
        }
        #undef COPY
    }
    else if (version_num >= 2 && version_num <= 5)
    {
        ModelLODInfoOnDisk_v5 *lod_data = (void *)data;
        for (j = 0; j < model_count; j++)
        {
            ModelLODInfo *lod_info = &lod_infos[j];
            bytes_read += sizeof(*lod_data);
            for (i = 0; i < lod_data[j].num_lods; i++)
            {
                AutoLOD *lod = allocAutoLOD();
                eaPush(&lod_info->lods, lod);

                lod->flags = lod_data[j].lods[i].flags;
                lod->lod_far = lod_data[j].lods[i].lod_far;
                lod->lod_farfade = lod_data[j].lods[i].lod_farfade;
                lod->lod_near = lod_data[j].lods[i].lod_near;
                lod->lod_nearfade = lod_data[j].lods[i].lod_nearfade;
                lod->max_error = lod_data[j].lods[i].max_error;
            }
        }
    }
    else
    {
        assert(0);
    }

    assert(bytes_read <= memsize);

    return lod_infos;
}

_Static_assert(sizeof(AutoLODOnDisk_v5)==24,"original scalar layout");
_Static_assert(sizeof(ModelLODInfoOnDisk_v5)==148,"original fixed row layout");
int main(int argc,char**argv){assert(argc==3);unsigned count=(unsigned)strtoul(argv[2],NULL,10);assert(count>0&&count<=65536);FILE*f=fopen(argv[1],"rb");assert(f&&!fseek(f,0,SEEK_END));long n=ftell(f);assert(n>0&&n<16*1024*1024);rewind(f);char*raw=malloc((size_t)n);assert(raw&&fread(raw,1,(size_t)n,f)==(size_t)n&&!fclose(f));ModelLODInfo*info=unpackLODInfo(raw,(int)n,(int)count,3);assert(info);
for(unsigned r=0;r<count;r++){EA*e=info[r].lods?(EA*)((char*)info[r].lods - offsetof(EA,rows)):NULL;uint32_t num=e?e->count:0;assert(fwrite(&num,4,1,stdout)==1);for(unsigned j=0;j<num;j++){AutoLOD*l=e->rows[j];float fields[]={l->max_error,l->lod_near,l->lod_far,l->lod_nearfade,l->lod_farfade};assert(fwrite(fields,4,5,stdout)==5&&fwrite(&l->flags,4,1,stdout)==1);free(l->lod_modelname);free(l->lod_filename);free(l);}free(e);}free(info);free(raw);return 0;}
