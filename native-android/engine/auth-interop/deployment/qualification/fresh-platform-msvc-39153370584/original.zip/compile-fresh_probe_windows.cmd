@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
if errorlevel 1 exit /b 1
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe" /nologo /TC /std:c11 /W4 /WX /MT /showIncludes /D_CRT_SECURE_NO_WARNINGS /DWIN32_LEAN_AND_MEAN /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 /ID:\a\_temp\retained-intact\intact-openssl-reuse\include /ID:\a\coh-android\coh-android\native-android\include /O2 /c /FoD:\a\coh-android\coh-android\out\fresh-platform\fresh_probe_windows.obj D:\a\coh-android\coh-android\native-android\engine\auth-interop\fresh-character-owner\probe\windows\fresh_probe_windows.c
exit /b %errorlevel%
