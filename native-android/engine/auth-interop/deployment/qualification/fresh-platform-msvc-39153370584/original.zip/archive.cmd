@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
if errorlevel 1 exit /b 1
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\lib.exe" /nologo /OUT:D:\a\coh-android\coh-android\out\fresh-platform\coh-fresh-platform.lib D:\a\coh-android\coh-android\out\fresh-platform\fresh_probe_windows.obj D:\a\coh-android\coh-android\out\fresh-platform\fresh_probe_policy.obj
exit /b %errorlevel%
