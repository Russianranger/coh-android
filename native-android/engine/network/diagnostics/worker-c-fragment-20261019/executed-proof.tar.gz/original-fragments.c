
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "coh_native_core.h"
typedef uint32_t U32;typedef uint8_t U8;
typedef enum {Read,Write} BitStreamMode;
typedef enum {BSE_NOERROR,BSE_OVERFLOW,BSE_OVERRUN,BSE_TYPEMISMATCH,BSE_COMPRESSION} BitStreamError;
typedef struct {unsigned int byte,bit;} BitStreamCursor;
typedef struct BitStream BitStream;typedef int (*MemoryAllocator)(BitStream*);
struct BitStream {BitStreamMode mode;BitStreamCursor cursor;unsigned char *data;unsigned int size,maxSize,bitLength;MemoryAllocator memAllocator;void *userData;unsigned int byteAlignedMode;BitStreamError errorFlags;};

typedef float F32;
typedef struct {BitStream stream;U32 checksum,truncatedID,sib_count,sib_partnum,sib_id,hasDebugInfo,compress,ordered,ordered_id,id,UID,xferTime,inSendQueue,reliable;} Packet;
typedef struct {Packet *items[16];unsigned count;} TestQueue;


typedef struct {int ack_count;U32 ids_toack[32];int compressionAllowed,orderedAllowed;unsigned socket,type,nextID,nextSibID,sendQueuePacketMax,sendQueuePacketCount,last_ordered_sent_id,reliablePacketsQueued,overflow,totalQueuedBytes;float runningCompressionRatio;void *zstream_pack;TestQueue *sendQueue2;struct {unsigned sin_port;struct {struct {unsigned S_addr;}S_un;}sin_addr;}addr;} NetLink;

#define false 0
#define true 1
#define BSASSERT(x) assert(x)
#define MAX(a,b) ((a)>(b)?(a):(b))
#define ROUND_BITS_UP(x) (((x)+7)&~7)
#define PACKET_MISCINFO_SIZE_WITH_DEBUG 200
#define PACKET_MISCINFO_SIZE_WITHOUT_DEBUG 36
#define COMM_CONNECT 1
#define MAX_PKTACKS 32
static unsigned int g_packetsizes_one[33],g_packetsizes_success[33],g_packetsizes_failed[33];
static int count_bits(unsigned int val){int n=0;do{val>>=1;n++;}while(val);return n;}
void bsAlignByte(BitStream*);unsigned int bsGetCursorBitPosition(BitStream*);unsigned int bsGetBitLength(BitStream*);
void bsWriteBits(BitStream*,int,unsigned int);void bsWriteBitsPack(BitStream*,int,unsigned int);unsigned int bsReadBitsPack(BitStream*,int);
static int printPacketSendData=0,printPacketGetData=0;
static void bsTypedWriteBits(BitStream *b,int n,U32 v){(void)b;(void)n;(void)v;assert(0);}
static void bsTypedWriteBitsPack(BitStream *b,int n,U32 v){(void)b;(void)n;(void)v;assert(0);}
static U32 bsTypedReadBitsPack(BitStream *b,int n){(void)b;(void)n;assert(0);return 0;}
static void bsTypedWriteBitsArray(BitStream *b,int n,const void *v){(void)b;(void)n;(void)v;assert(0);}
int bsGetLengthWriteBitsPack(BitStream*,int,U32);static int pktGetLengthBitsPack(Packet*p,int n,U32 v){return bsGetLengthWriteBitsPack(&p->stream,n,v);}
void pktSendBitsAuto(Packet*,U32);int auto_bins[]={2,10,24,32};
static int cmpU32(const void *a,const void *b){return *(const U32*)a>*(const U32*)b;}
extern U32 cryptAdler32(U8*,int);

#include <zlib.h>
#define MEM_DBG_PARMS
#define LOG(...)
#define verify(x) (x)
#define NLT_NONE 0
#define NLT_UDP 1
#define NLT_TCP 2
#define netioEnterCritical() ((void)0)
#define netioLeaveCritical() ((void)0)
#define timerCpuTicks() 1
#define lnkAddSendTime(...) ((void)0)
#define lnkFlushAddLink(...) ((void)0)
static int g_assert_on_netlink_overflow=0,total_sendqueue_overflows=0;
static int sendPacketBufferSize=1236;
static const char *makeIpStr(unsigned a){(void)a;return "synthetic";}
static int qEnqueue(TestQueue *q,Packet*p){assert(q->count<16);q->items[q->count++]=p;return 1;}
void initBitStream(BitStream*,U8*,unsigned int,BitStreamMode,unsigned int,MemoryAllocator);
static Packet *pktCreate(void){Packet*p=calloc(1,sizeof(*p));assert(p);U8*b=calloc(16384,1);assert(b);initBitStream(&p->stream,b,16384,Write,0,0);return p;}
static void pktFree(Packet*p){free(p->stream.data);free(p);}
static void bsCompress(BitStream*s,int dbg,void*z){(void)s;(void)dbg;(void)z;assert(0);}
void initBitStream(BitStream* bs, unsigned char* buffer, unsigned int bufferSize, BitStreamMode initMode, unsigned int byteAligned, MemoryAllocator alloc){
    memset(bs, 0, sizeof(BitStream));
    bs->data = buffer;
    bs->maxSize = bufferSize;
    bs->memAllocator = alloc;
    bs->mode = initMode;
    //memset(bs->data, 0, bufferSize);
    bs->data[0] = 0;
    bs->data[1] = 0;
    bs->data[2] = 0;
    bs->data[3] = 0;
    bs->byteAlignedMode=byteAligned;
}

void bsSetByteAlignment(BitStream* bs, int align) {
    bs->byteAlignedMode = align;
    if (align)
        bsAlignByte(bs);
}

void bsWriteBits(BitStream* bs, int numbits, unsigned int val){

    if (bs->errorFlags) {
        // Can't write to a stream in an erroneous state!
        return;
    }

    // Make sure the given bitstream is in write mode.
    if(bs->mode != Write){
        assert(0);
        return;
    }

    assert(numbits<=32);

    if (numbits == 0)
        return;

    if (bs->byteAlignedMode) {
        if (numbits!=32) { // Mask out bits that we don't want sent
            int mask = ((1 << numbits)-1);
            val = val & mask;
        }
        numbits = ROUND_BITS_UP(numbits);
        assert(bs->cursor.bit==0);

    }

    // See if we need to increase the max size
    {
        unsigned int lastByteModified = bs->cursor.byte + ROUND_BITS_UP(bs->cursor.bit + numbits);
        if (lastByteModified > bs->maxSize)
        {
            if (bs->memAllocator)
            {
                bs->memAllocator(bs);
                assert(lastByteModified < bs->maxSize);
            }
            else
            {
                // Apparently this should never happen
                BSASSERT(!"No memory allocator and we need more");
                bs->errorFlags = BSE_OVERFLOW;
                return;
            }
        }
    }

#if 1
    // Setup and do 32-bit copies
    {
        char *cursor_byte = bs->data + bs->cursor.byte;
        U32 *cursor_U32 = (U32*)((size_t)cursor_byte & ~3);
        U32 cursor_U32_bit = bs->cursor.bit + 8 * ((size_t)cursor_byte & 3);
        U32 old_mask = (1 << cursor_U32_bit)-1;

        // Do shifted 32-bit masked copy
        if (cursor_U32_bit > 0)
        {
            int max_bits_to_copy = 32 - cursor_U32_bit;

            int bits_to_copy = (numbits < max_bits_to_copy) ? numbits : max_bits_to_copy;

            *cursor_U32 = (*cursor_U32 & old_mask) | ((val & ((1 << bits_to_copy)-1)) << cursor_U32_bit);

            val >>= bits_to_copy;
            cursor_U32_bit += bits_to_copy;

            bs->cursor.byte = (unsigned int)(((size_t)cursor_U32 + (cursor_U32_bit >> 3)) - (size_t)bs->data);
            bs->cursor.bit = cursor_U32_bit & 7;

            numbits -= bits_to_copy;

            cursor_U32 += cursor_U32_bit >> 5;
            cursor_U32_bit &= 31;
            old_mask = (1 << cursor_U32_bit)-1;
        }

        // Do 32-bit copy
        if (numbits == 32)
        {
            assert(bs->cursor.bit == 0);
            assert(cursor_U32_bit == 0);

            *cursor_U32 = val;
            bs->cursor.byte += 4;
            numbits = 0;
        }
        // Do 32-bit masked copy
        else if (numbits)
        {
            int bits_to_copy = numbits;

            assert(bs->cursor.bit == 0);
            assert(cursor_U32_bit == 0);

            // NOTE: 1 << bits_to_copy will overfloat the 32-bit integer when bits_to_copy is 32.
            // That's why we have the "Do 32-bit copy" section above
            *cursor_U32 = (val & ((1 << bits_to_copy)-1));

            cursor_U32_bit += bits_to_copy;

            bs->cursor.byte = (unsigned int)(((size_t)cursor_U32 + (cursor_U32_bit >> 3)) - (size_t)bs->data);
            bs->cursor.bit = cursor_U32_bit & 7;

            numbits -= bits_to_copy;
        }
    }
#else
    // OLD 8-bit logic (cleaned up) for reference

    // OPTIMIZATION: Fast pass for doing byte copies
    if (bs->cursor.bit == 0)
    {
        while(numbits >= 8)
        {
            bs->data[bs->cursor.byte] = val & 0xFF;

            val >>= 8;
            bs->cursor.byte++;
            numbits -= 8;
        }
    }

    // Insert the bits now.
    while(numbits)
    {
        int outBits, bits;

        if (bs->cursor.bit == 0)
            bs->data[bs->cursor.byte] = 0;

        // Calculate the number of bits to be outputted this iteration.
        //    How many bits until the current byte is filled?
        outBits = 8 - bs->cursor.bit;

        //    Is it possible to send all remaining bits?  Or do we have to settle for filling this
        //    byte only?
        bits = (numbits < outBits) ? numbits : outBits;

        // Mask out data that is not wanted, then put it at the correct bit location
        // as specified by the cursor.
        bs->data[bs->cursor.byte] |= (val & ((1 << bits)-1)) << bs->cursor.bit;

        val >>= bits;
        bs->cursor.bit += bits;

        // Normalize cursor.
        bs->cursor.byte += bs->cursor.bit >> 3;
        bs->cursor.bit &= 7;

        numbits -= bits;
    }
#endif

    // The other bsWrite functions assume that the next byte is zeroed out
    if (bs->cursor.bit == 0)
        bs->data[bs->cursor.byte] = 0;

    // Only increase size if cursor is beyond it.
    // We don't want to increase the size when we're overwriting data in the middle!
    bs->size = MAX(bs->size, bs->cursor.byte);

    assert(bs->size <= bs->maxSize);

    // Update the recorded bitlength of the stream.
    {
        unsigned int cursorBitPos;
        cursorBitPos = bsGetCursorBitPosition(bs);
        bs->bitLength = MAX(bs->bitLength, cursorBitPos);
    }

}

unsigned int bsReadBits(BitStream* bs, int numbits){
    unsigned int        val = 0;
    int        in_bits, curr_shift=0, bits;

    if (bs->errorFlags) {
        return -1;
    }

    assert(numbits <= 32);

    if (bs->byteAlignedMode) {
        numbits = ROUND_BITS_UP(numbits);
    }

    if ((bs->cursor.byte<<3) + bs->cursor.bit + numbits > bs->bitLength) {
        BSASSERT(!"Read off of the end of the bitstream!");
        bs->errorFlags = BSE_OVERRUN;
        return -1;
    }

    while(1)
    {
        in_bits = 8 - bs->cursor.bit;
        bits = (numbits < in_bits) ? numbits : in_bits;
        val |= ((bs->data[bs->cursor.byte] >> bs->cursor.bit) & ((1 << bits)-1)) << curr_shift;
        bs->cursor.bit += bits;
        if (bs->cursor.bit >= 8)
        {
            bs->cursor.bit = 0;
            bs->cursor.byte++;
        }
        curr_shift += bits;
        numbits -= bits;
        if (numbits <= 0)
            break;
    }
    return val;
}

int bsWriteBitsArray(BitStream* bs, int numbits, const void* data){
    int    fullBytes;
    //int bytesAdded;
    //int bitsAdded;

    // Note: this always aligns to bytes currently, if that changes, we'll need to add a case for byteAligned here

    // Make sure the given bitstream is in write mode.
    if(bs->mode != Write){
        assert(0);
        return 0;
    }

    if (bs->errorFlags) {
        return 0;
    }

    // How many full bytes are being sent?
    fullBytes = (numbits + 7) >> 3;

    // Align the bitstream cursor with the next byte.
    // This prepares the bitstream for a direct memory copy, avoiding
    // any bit alignment issues.
    if(bs->cursor.bit){
        bs->bitLength += 8 - bs->cursor.bit;
        bs->cursor.bit = 0;
        bs->cursor.byte++;
        if (bs->size<bs->cursor.byte)  // Only increase size if cursor matches it, we don't want to increase the size when we're overwriting data in the middle!
            bs->size++;
        assert(bs->size>=bs->cursor.byte);
    }

    // Make sure there is enough room in the bitstream buffer to hold the
    // incoming data.
    while((bs->cursor.byte + fullBytes) >= bs->maxSize){
        if(bs->memAllocator){
            bs->memAllocator(bs);
        }else {
            BSASSERT(!"No memory allocator and we need more");
            bs->errorFlags = BSE_OVERFLOW;
            return 0;
        }
    }

    // Copy the given data into the bitstream.
    memcpy(&bs->data[bs->cursor.byte], data, fullBytes);

    // Update bitstream cursor.
    bs->size += fullBytes;
    bs->cursor.byte += fullBytes;
    bs->bitLength += numbits;
    //JE: Note that right here cursor.byte and bitLength and inconsistent with eachother!  Unfortunately,
    //  that's the way it was, and that's the way it's gotta be for now, since we often "duplicate" one
    //  stream into another by using this function, and we expect the bitLength of the two to be the
    //  same!  But, if anything gets appended to this, we would want it to start at the next byte (although
    //  I don't think that happens)

    bs->data[bs->cursor.byte] = 0;
    return 1;
}

void bsWriteBitsPack(BitStream* bs, int minbits, unsigned int val){
    unsigned int bitmask;
    int success = 1;
    int one = minbits == 1;
    int measured_bits = count_bits(val);

    if (bs->byteAlignedMode) {
        bsWriteBits(bs, 32, val);
        return;
    }
    if (bs->errorFlags) {
        return;
    }

    for(;;)
    {
        // Produce a minbits long mask that contains all 1's
        bitmask = (1 << minbits)-1;

        // If the value to be written can be represented by minbits...
        if (val < bitmask || minbits >= 32)
        {
            // Write the value.
            bsWriteBits(bs,minbits,val);
            if (success)
                g_packetsizes_success[measured_bits]++;
            else
                g_packetsizes_failed[measured_bits]++;
            if (one)
                g_packetsizes_one[measured_bits]++;
            break;
        }
        bsWriteBits(bs,minbits,bitmask);
        minbits <<= 1;
        if (minbits > 32)
            minbits = 32;
        val -= bitmask;
        success = 0;
    }
}

unsigned int bsReadBitsPack(BitStream* bs,int minbits){
    unsigned int val, base=0;
    unsigned int bitmask;
    int success = 1;
    int one = minbits == 1;

    if (bs->byteAlignedMode) {
        return bsReadBits(bs, 32);
    }

    if (bs->errorFlags) {
        return -1;
    }

    for(;;)
    {
        val = bsReadBits(bs,minbits);
        if (bs->errorFlags)
            return -1;
        bitmask = (1 << minbits)-1;
        if (val < bitmask || minbits == 32)
        {
            int measured_bits = count_bits(val+base);
            if (success)
                g_packetsizes_success[measured_bits]++;
            else
                g_packetsizes_failed[measured_bits]++;
            if (one)
                g_packetsizes_one[measured_bits]++;
            return val + base;
        }
        base += bitmask;
        minbits <<= 1;
        if (minbits > 32)
            minbits = 32;
        success = 0;
    }
    return val + base;
}

void bsRewind(BitStream* bs){
    bs->cursor.byte = 0;
    bs->cursor.bit = 0;
    bs->errorFlags = BSE_NOERROR;
}

void bsAlignByte(BitStream* bs){
    if(bs->cursor.bit){
        bs->cursor.byte++;
        if (bs->mode == Write) {
            if (bs->size < bs->cursor.byte) {  // Only increase size if cursor matches it, we don't want to increase the size when we're overwriting data in the middle!
                bs->size++;
                bs->bitLength += 8 - bs->cursor.bit;
                bs->data[bs->size]=0; // Because the data might not be zeroed out to start with?
            }
        }
        bs->cursor.bit = 0;
    }
}

unsigned int bsGetCursorBitPosition(BitStream* bs){
    return (bs->cursor.byte << 3) + bs->cursor.bit;
}

unsigned int bsGetBitLength(BitStream* bs){
    return bs->bitLength;
}

void bsSetCursorBitPosition(BitStream* bs, unsigned int position){
    assert (position <= bs->bitLength);
    bs->cursor.byte = position >> 3;
    bs->cursor.bit = position & 7;
}

void bsSetEndOfStreamPosition(BitStream *bs, unsigned int position){
    bsSetCursorBitPosition(bs, position);
    bs->size = bs->cursor.byte;
    bs->bitLength = bsGetCursorBitPosition(bs);
    // Write zeroes to the rest of the byte we're at
    bs->data[bs->cursor.byte] &= (1 << bs->cursor.bit)-1;
}

int bsGetLengthWriteBits(BitStream* bs, int numbits, unsigned int val){
    int    outBits, bits;
    int ret=0;

    if (bs->errorFlags) {
        // Can't write to a stream in an erroneous state!
        return 0;
    }

    if (bs->byteAlignedMode) {
        if (numbits!=32) { // Mask out bits that we don't want sent
            int mask = ((1 << numbits)-1);
            val = val & mask;
        }
        numbits = ROUND_BITS_UP(numbits);
        assert(bs->cursor.bit==0);
    }
    assert(numbits<=32);

    // Make sure the given bitstream is in write mode.
    if(bs->mode != Write){
        assert(0);
        return 0;
    }

    // Insert the bits now.
    while(1){
        // Calculate the number of bits to be outputted this iteration.
        //    How many bits until the current byte is filled?
        outBits = 8 - bs->cursor.bit;

        //    Is it possible to send all remaining bits?  Or do we have to settle for filling this
        //    byte only?
        bits = (numbits < outBits) ? numbits : outBits;

        // Mask out data that is not wanted, then put it at the correct bit location
        // as specified by the cursor.
        //NOT HERE bs->data[bs->cursor.byte] |= (val & ((1 << bits)-1)) << bs->cursor.bit;

        val >>= bits;
        //NOT HERE bs->cursor.bit += bits;
        ret += bits;

        //NOT HERE Normalize cursor.
        numbits -= bits;
        if (numbits <= 0)
            break;
    }

    //NOT HERE Update the recorded bitlength of the stream.
    return ret;
}

int bsGetLengthWriteBitsPack(BitStream* bs, int minbits, unsigned int val){
    unsigned int bitmask;
    int ret=0;

    if (bs->byteAlignedMode) {
        return bsGetLengthWriteBits(bs, 32, val);
    }
    if (bs->errorFlags) {
        return 0;
    }

    for(;;)
    {
        // Produce a minbits long mask that contains all 1's
        bitmask = (1 << minbits)-1;

        // If the value to be written can be represented by minbits...
        if (val < bitmask || minbits >= 32)
        {
            // Write the value.
            ret += bsGetLengthWriteBits(bs,minbits,val);
            break;
        }
        ret += bsGetLengthWriteBits(bs,minbits,bitmask);
        minbits <<= 1;
        if (minbits > 32)
            minbits = 32;
        val -= bitmask;
    }
    return ret;
}

unsigned int bsGetLength(BitStream* bs){
    return ((bs->cursor.byte << 3) + bs->cursor.bit) >> 3;
}

void pktSetByteAlignment(Packet* pak, int align)
{
    bsSetByteAlignment(&pak->stream, align);
}

void pktSendBits(Packet *pak,int numbits,U32 val){
    if(printPacketSendData)
        printf("sending %d bits: %d\n", numbits, val & ((1 << numbits) - 1));

    if(pak->hasDebugInfo)
        bsTypedWriteBits(&pak->stream, numbits, val);
    else
        bsWriteBits(&pak->stream, numbits, val);
}

void pktSendBitsPack(Packet *pak,int minbits,U32 val){
    if(printPacketSendData)
        printf("sending %d bits pack: %d\n", minbits, val);

    if(pak->hasDebugInfo)
        bsTypedWriteBitsPack(&pak->stream, minbits, val);
    else
        bsWriteBitsPack(&pak->stream, minbits, val);
}

U32 pktGetBitsPack(Packet *pak,int minbits){
    if(printPacketGetData)
        printf("getting %d bits pack\n", minbits);

    if(pak->hasDebugInfo)
        return bsTypedReadBitsPack(&pak->stream, minbits);
    else
        return bsReadBitsPack(&pak->stream, minbits);
}

void pktSendBitsArray(Packet *pak,int numbits,const void *data){
    if(printPacketSendData)
        printf("sending %d bits array\n", numbits);

    if(pak->hasDebugInfo)
        bsTypedWriteBitsArray(&pak->stream, numbits, data);
    else
        bsWriteBitsArray(&pak->stream, numbits, data);
}

void pktMakeCompatible(Packet *pak, Packet const *pak_in)
{
    pak->reliable = pak_in->reliable;
    pak->hasDebugInfo = pak_in->hasDebugInfo;
    pak->compress = pak_in->compress;
    pak->ordered = pak_in->ordered;
}

U32 pktGetSize(Packet *pak){
    assert(pak);
    return bsGetLength(&pak->stream);
}

void pktSendBitsAuto(Packet *pak, U32 val)
{
    int bin, bits = count_bits(val);
    for (bin = 0; bin < 4; bin++)
        if (auto_bins[bin] >= bits) break;
    pktSendBits(pak, 2, bin);
    pktSendBits(pak, auto_bins[bin], val);

    // test this for a bit?
    if (auto_bins[bin] < 32)
    {
        unsigned int bitmask = (unsigned int)(1 << auto_bins[bin]) - (unsigned int)1;
        assert((val & ~bitmask) == 0);
    }
}

U32 pktSendAcks(Packet* pak, NetLink* link, int sendRequestCount, int* lastSentIndex, unsigned int maxPacketHeaderSize)
{
    int sentCount = 0;
    int i;
    assert(lastSentIndex);

    pktSendBitsPack(pak, 1, sendRequestCount);
    if(sendRequestCount){
        // Add all the ack's into the packet.
        // The first acknowledgement is sent using the "full", "truncated" ID of the packet to be ack'ed.
        pktSendBits(pak, 32, link->ids_toack[0]);
        sentCount++;
        *lastSentIndex = 0;

        //if (!pak->hasDebugInfo)
        //    assert(pak->stream.size < PACKET_MISCINFO_SIZE);

        // Subsequent acknowledgements are sent in incremental form.
        for(i = 1; i < link->ack_count && sentCount < sendRequestCount; i++){
            // Skip all acks with the same sequence number.
            if(link->ids_toack[i] == link->ids_toack[i-1])
                continue;

            {
                int value = link->ids_toack[i] - link->ids_toack[i-1] - 1;
                int len = pktGetLengthBitsPack(pak, 1, value);
                if (pak->stream.bitLength + len >= maxPacketHeaderSize*8) {
                    break;
                }

                pktSendBitsPack(pak, 1, value);
                sentCount++;
                *lastSentIndex = i;
            }
        }

        if (!pak->hasDebugInfo && pak->sib_count < 32) // With a lot of sib packets (should only happen with the editor) this might go over the limit on the first ack!
            assert(pak->stream.size <= maxPacketHeaderSize);
    }

    return sentCount;
}

U32 pktWrap(Packet* pak_in, NetLink* link, BitStream* stream)
{
    int i;
    //BitStream cloneStream;
    int uniqueAckCount = 0;
    static int send_count;
    Packet* pak;
    Packet pak_buf;
    unsigned int bitLengthPosition;
    int cmd=-1;
    unsigned int maxPacketHeaderSize = (pak_in->hasDebugInfo?PACKET_MISCINFO_SIZE_WITH_DEBUG:PACKET_MISCINFO_SIZE_WITHOUT_DEBUG) - 8; // - blowfish pad
    //int maxPacketDataSize = sendPacketBufferSize - maxPacketHeaderSize;

    // Get the cmd from the packet
    if (!pak_in->sib_id) {
        bsRewind(&pak_in->stream);
        cmd = pktGetBitsPack(pak_in, 1);
        bsRewind(&pak_in->stream);
    }

    // Create a dummy packet to be filled with real outgoing data.
    pak = &pak_buf;
    *pak = *pak_in;
    pak->stream = *stream;

    // Write out a dummy bitlength
    //cloneBitStream(stream, &cloneStream);    // Save the place where the bitlength should be written to.
                                            // FIXME! The bitstream should know how to position itself without
                                            //          choking.  Implement something like ftell and fseek.
    bitLengthPosition = bsGetCursorBitPosition(stream);
    bsWriteBits(&pak->stream, 32, 0); //pak->stream.cursor.byte += 4;
    

    // FIXME!! Put in the checksum!
    // Calculate the checksum of the data held in the packet.
    bsWriteBits(&pak->stream, 32, pak_in->checksum);
    //*((int*)&pak->stream.data[pak->stream.cursor.byte]) = pak_in->checksum;
    //pak->stream.cursor.byte += 4;

    pak->stream.data[pak->stream.cursor.byte] = 0;
    assert(pak->stream.cursor.bit==0);

    bsWriteBits(&pak->stream, 1, pak_in->hasDebugInfo);

    pktSendBits(pak, 32, pak_in->truncatedID);

    // Has this packet been split up?
    pktSendBitsPack(pak, 1, pak_in->sib_count);
    if (pak_in->sib_count)
    {
        // If so, add identifiers to uniquely idenfity which
        // sibling this packet is.
        pktSendBitsPack(pak, 1, pak_in->sib_partnum);
        pktSendBits(pak, 32, pak_in->sib_id);
    }

    // Want to piggy back acknowlegements for received packets?
    // Count how many acks should be sent with this packet.
    if(link->ack_count){
        assert(link->ack_count < MAX_PKTACKS);

        // Sort all acks in increasing order.
        qsort(link->ids_toack,link->ack_count,sizeof(U32),
            cmpU32);

        // Count how many unique acks there are.
        uniqueAckCount = 1;                    // There is at least one unique ack.
        for(i=1;i<link->ack_count;i++){
            // Skip all acks with the same sequence number.
            if(link->ids_toack[i] == link->ids_toack[i-1])
                continue;

            uniqueAckCount++;
        }
    }    

    {
        int bitCursor = bsGetCursorBitPosition(&pak->stream);
        int sentCount;
        int sendReqCount = uniqueAckCount;
        int lastSentIndex = 0;

        // try to send all acks.
        sentCount = pktSendAcks(pak, link, sendReqCount, &lastSentIndex, maxPacketHeaderSize);

        // If it is not possible to set all acks, restore the bitstream cursor
        // and place the proper number of acks into the packet.
        if(sentCount != sendReqCount)
        {
            sendReqCount = sentCount;
            bsSetEndOfStreamPosition(&pak->stream, bitCursor);
            sentCount = pktSendAcks(pak, link, sendReqCount, &lastSentIndex, maxPacketHeaderSize);
            assert(sentCount == sendReqCount);
        }

        // Get rid of the sent acks.
        if(sentCount)
        {
            memmove(link->ids_toack, &link->ids_toack[lastSentIndex+1], (link->ack_count - (lastSentIndex+1))*sizeof(int));
            link->ack_count -= (lastSentIndex+1);
        }
    }

    if (link->compressionAllowed && cmd!=COMM_CONNECT) {
        // Only with version 1+ packets, and *not* on the connect packet under
        //  any circumstances (it was doing it when re-transmitting the
        //  packet)
        pktSendBits(pak, 1, pak->compress);
    } else {
        assert(!pak->compress);
    }

    // ordered
    if(link->orderedAllowed && cmd!=COMM_CONNECT)
    {
        pktSendBits(pak,1,pak->ordered);
        if( pak->ordered )
        {
            pktSendBitsAuto( pak, pak->ordered_id );
        }
    }

    // Pack up all the data in the given packet.
    pktSetByteAlignment(pak, link->compressionAllowed && pak->compress); // This is only needed so that the packetdebug info gets aligned as well, since sendBitsArray auto-aligns
    pktSendBitsArray(pak, bsGetBitLength(&pak_in->stream), pak_in->stream.data);
    

    // Write out the actual bitlength of the stream now.
    assert((bitLengthPosition & 7) == 0); // If it's not, we need to turn off byte aligning, write the data (and then turn it back on?)
    bsSetCursorBitPosition(&pak->stream, bitLengthPosition);
    bsWriteBits(&pak->stream, 32, bsGetBitLength(&pak->stream));
    // Seek to the end when done?  Not really needed.
    // The clone stream is still pointing at the beginning of the stream.
    ////bsWriteBits(&cloneStream, 32, bsGetBitLength(&pak->stream));
    //*((int*)&cloneStream.data[0]) = bsGetBitLength(&pak->stream);

    assert(!pak->stream.errorFlags);

    *stream = pak->stream;

    return 1;
}

int blowfishPad(int num){
    return 4 + ((num -4 +7) & ~7);
}

int lnkAddToSendQueue(NetLink* link, Packet** pakptr, int sibling_packet)
{
    Packet* pak = *pakptr;
    // Attempt to enqueue the packet into the send queue.

    LOG(LOG_NET, LOG_LEVEL_DEBUG, 0, "ID: %i, msg: queuing packet to send, addr: %x, req loc: %s, %i\n", pak->UID, pak, __FILE__, __LINE__);

    if (!sibling_packet && link->sendQueuePacketMax && link->sendQueuePacketCount >= link->sendQueuePacketMax)
    {
        // Unable to enqeue packet.

        // There wasn't any room in the send queue.  The packet will be discarded
        // regardless of the type (reliable/unreliable).
        // Note that if there isn't any room in the send queue and the packet is not
        // marked as reliable, the packet would be silently dropped.
        //
        // This should never happen under normal circumstances.
        // The packet code always clears out the send queue every tick.  The only way 
        // the send queue can be overflowed is by sending NETLINK_SENDQUEUE_MAX_SIZE 
        // number of packets all at once.  Note that if this happens, one way to cope 
        // with the problem is to change NETLINK_SENDQUEUE_MAX_SIZE.  It would probably
        // be better to figure out why so many packets are being sent in one tick.
        //
        // JE: When lots of people are logging into the dbserver on the same tick the sendQueue will
        // overflow, also, when writing via TCP to a hung mapserver, the sendQueue
        // can fill up.  Also some odd circumstance on the Updater is causing this to happen...

        // FIXME!    -    Although overflows should never happen under normal usage,
        //                it might be a good idea to deal with this error more gracefully.

        if(pak->reliable){
            static int lastport=0;
            if (g_assert_on_netlink_overflow) {
                assert(0);
            }
            link->overflow = 1;
            total_sendqueue_overflows++;
            if (link->addr.sin_port!=lastport) {
                printf("Send queue overflow to %s:%d (%d total)!\n", makeIpStr(link->addr.sin_addr.S_un.S_addr), link->addr.sin_port, total_sendqueue_overflows);
                lastport = link->addr.sin_port;
                LOG(LOG_NET, LOG_LEVEL_DEBUG, 0, "Overflow(s) adding packet uid: %d to sendQueue to %s:%d, %d total overflows", pak->UID, makeIpStr(link->addr.sin_addr.S_un.S_addr), link->addr.sin_port, total_sendqueue_overflows);
            }
        }

        LOG(LOG_NET, LOG_LEVEL_DEBUG, 0, "ID: %i, msg: cannot queue packet, addr: %x, req loc: %s, %i\n", pak->UID, pak, __FILE__, __LINE__);
        // Return an error code.
        return 0;
    }
    if (!sibling_packet) {
        link->sendQueuePacketCount++;
    }

    {
        int ret = qEnqueue(link->sendQueue2, pak);
        assert(ret);
    }

    // Packet enqueued properly.
    // Assign it an ID.
    pak->id = ++link->nextID;
    //pak->truncatedID = pak->id & ((1 << 16) - 1);
    pak->truncatedID = pak->id;
    pak->xferTime = timerCpuTicks();    // Fake the send time for network condition simulation.
    pak->inSendQueue = 1;
    lnkAddSendTime(link, pak->id, pak->xferTime);

    if( pak->ordered && !sibling_packet && link->type == NLT_UDP && verify(!pak->ordered_id && pak->reliable) )
        pak->ordered_id = ++link->last_ordered_sent_id;

    if(pak->reliable)
        link->reliablePacketsQueued++;

    LOG(LOG_NET, LOG_LEVEL_DEBUG, 0, "ID: %i, msg: queued packet, OutID: %i, addr: %x, req loc: %s, %i\n", pak->UID, pak->id, pak, __FILE__, __LINE__);
    *pakptr = NULL;

    // New data has just been queued into the link for sending.
    // Add this link to the list of links to be flushed.
    lnkFlushAddLink(link);

    return 1;
}

U32 pktSendDbg(Packet** pakptr, NetLink* link MEM_DBG_PARMS)
{
    Packet* pak_in;
    Packet* pak;
    int        i,bitlen, totalSiblingCount;
    int        maxPacketDataSize;
    U32        sizeOfPacket;

    //printf("*** SENDING PACKET %d: %d bytes\n", time(NULL) % 10, (*pakptr)->stream.size);
    netioEnterCritical();
    if (!link || !link->socket || NLT_NONE == link->type)
    {
        pktFree(*pakptr);
        *pakptr = NULL;
        netioLeaveCritical();
        return 0;
    }


    pak_in = *pakptr;
    // Compress the bitstream
    if(link->compressionAllowed && pak_in->compress)
    {
        F32 before_size = (F32)pktGetSize(pak_in);
        F32 after_size;
        F32 compression_ratio;
        
        // if this is a tcp connection, or its ordered and reliable
        // use the link's streaming facility, otherwise just
        // compress the individual packet
        if(link->type==NLT_TCP || (pak_in->ordered && pak_in->reliable))
        {
            if (!link->zstream_pack)
            {
                link->zstream_pack = calloc(sizeof(z_stream),1);
                deflateInit(link->zstream_pack,Z_DEFAULT_COMPRESSION);
            }
            bsCompress(&pak_in->stream, pak_in->hasDebugInfo, link->zstream_pack);
        }
        else
        {
            bsCompress(&pak_in->stream, pak_in->hasDebugInfo, NULL);
        }
        sizeOfPacket = pktGetSize(pak_in);
        after_size = (F32)sizeOfPacket;
        compression_ratio = before_size > 0 ? after_size/before_size : 0.f;
        
        link->runningCompressionRatio = link->runningCompressionRatio?(.9375f*link->runningCompressionRatio + .0625f*compression_ratio):compression_ratio;
    }
    else
        sizeOfPacket = pktGetSize(pak_in);
    //printf("Sending packet of size %d, bitLength %d\n", (*pakptr)->stream.size, (*pakptr)->stream.bitLength);

    maxPacketDataSize = sendPacketBufferSize - (pak_in->hasDebugInfo?PACKET_MISCINFO_SIZE_WITH_DEBUG:PACKET_MISCINFO_SIZE_WITHOUT_DEBUG);
    assert(maxPacketDataSize>0); // -packetdebug and -mtu < 201 will cause this
    // If the packet is not too large, just send the data.
    if(pak_in->stream.size < (unsigned int)maxPacketDataSize){
        int enqueueResult;

#if _CRTDBG_MAP_ALLOC
        //sprintf((*pakptr)->stack_dump,"%s: %d",caller_fname,line);
#endif
        enqueueResult = lnkAddToSendQueue(link, pakptr, 0);

        if(!enqueueResult){
            LOG(LOG_NET, LOG_LEVEL_DEBUG, 0, "ID: %i, msg: cannot enqueue packet for send, addr: %x, req loc: %s, %i\n", pak_in->UID, pak_in, __FILE__, __LINE__);
            pktFree(*pakptr);
            *pakptr = 0;
        }
        else
        {
            link->totalQueuedBytes += sizeOfPacket;
        }
        
        netioLeaveCritical();
        return enqueueResult;
    }

    LOG(LOG_NET, LOG_LEVEL_DEBUG, 0, "ID: %i, msg: splitting packets for send, addr: %x, req loc: %s, %i\n", pak_in->UID, pak_in, __FILE__, __LINE__);

    // The packet is too large to send all in one go...
    // The packet needs to be split up to smaller packets.
    // Assign the packet a new sibling ID.
    link->nextSibID++;

    // Calculate how many siblings there is going to be.
    totalSiblingCount = (pak_in->stream.size + maxPacketDataSize - 1) / maxPacketDataSize;

    // Split up the packet into smaller sibling packets and add them to the send queue.
    for(i=0;i<totalSiblingCount;i++)
    {
        int enqueueResult;
        pak = pktCreate(); // Not pktCreateEx because we do *not* have a CMD to send
        pak->sib_id = link->nextSibID;
        pak->sib_count = totalSiblingCount;
        pak->sib_partnum = i;
        //assert(pak->hasDebugInfo == pak_in->hasDebugInfo);
        pktMakeCompatible(pak,pak_in);
        
        bitlen = maxPacketDataSize * 8;    // The bit length for each sibling packet is equal.

        // Except for the last sibling packet.
        if (i == totalSiblingCount - 1)
            bitlen = bsGetBitLength(&pak_in->stream) - ((i * maxPacketDataSize) * 8);

        // Grab the piece of data that is supposed to be in this sibling packet.
        //    Do not use the pktSendBitsArray here.
        //    That function has now been changed to incorporate "type" information.
        //    Treat the packet as raw data and do not attach additional bitstream "type" info.
        //    This is done intentionally so that the split packets are of the same format as
        //    the other single packets.  The rest of the packet code can then just treat all
        //    packets as "single" packets without worrying where some additional type info might
        //    be attached.
        bsWriteBitsArray(&pak->stream, bitlen, pak_in->stream.data + i * maxPacketDataSize);
        
        // Send the sibling packet.
#if _CRTDBG_MAP_ALLOC
        //sprintf(pak->stack_dump,"%s: %d",caller_fname,line);
#endif

        enqueueResult = lnkAddToSendQueue(link, &pak, i!=0);
        if(!enqueueResult)
        {
            LOG(LOG_NET, LOG_LEVEL_DEBUG, 0, "ID: %i, msg: cannot enqueue packet for send, addr: %x, req loc: %s, %i\n", pak_in->UID, pak_in, __FILE__, __LINE__);
            pktFree(pak);
            break;
        }
        else if(i == 0)
            link->totalQueuedBytes += sizeOfPacket;
    }

    // The original packet has been split up into multiple child packets.  The original is no longer needed.
    pktFree(pak_in);
    *pakptr = NULL;
    
    netioLeaveCritical();
    return 0;
}

void original_produce(U32 bytes,U32 ordered,U8*frames,U32*sizes,U32*metadata,U32*count,U32*result){
 TestQueue queue={0};NetLink link={0};link.socket=1;link.type=NLT_UDP;link.nextID=101;link.compressionAllowed=1;link.orderedAllowed=1;link.sendQueue2=&queue;
 Packet *in=pktCreate();in->reliable=1;in->ordered=ordered;
 U32 data[4096]={0};for(U32 i=0;i<bytes;i++)((U8*)data)[i]=(U8)(i*17);((U8*)data)[0]=0x57;
 bsWriteBitsArray(&in->stream,bytes*8,data);*result=pktSendDbg(&in,&link);assert(!in);*count=queue.count;
 for(U32 i=0;i<queue.count;i++){
  Packet *p=queue.items[i];U32 output[512]={0};BitStream stream;initBitStream(&stream,(U8*)output,sizeof(output),Write,0,0);assert(pktWrap(p,&link,&stream));
  sizes[i]=blowfishPad((stream.bitLength+7)/8);assert(sizes[i]<=1472);memcpy(frames+i*1472,output,sizes[i]);
  metadata[i*5]=p->id;metadata[i*5+1]=p->sib_count;metadata[i*5+2]=p->sib_partnum;metadata[i*5+3]=p->sib_id;metadata[i*5+4]=p->ordered_id;pktFree(p);
 }
}
