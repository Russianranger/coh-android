#!/usr/bin/env python3
"""Original producer graph fixtures + bounded native ownership/negative checks."""
from pathlib import Path
import argparse, ctypes as C, hashlib, importlib.util, json, os, shutil, subprocess, tempfile, struct
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
def run(cmd,**kw):
    p=subprocess.run(cmd,text=True,capture_output=True,**kw)
    if p.returncode: raise RuntimeError(repr(cmd)+'\n'+p.stdout+p.stderr)
    return p


META_U32 = [('in_use','in_use'),('mod_time','mod_time'),('lod_fadenode','lod_fadenode'),('parent_fade','parent_fade'),('child_parent_fade','child_parent_fade'),('no_fog_clip','no_fog_clip'),('no_coll','no_coll'),('open_tracker','open_tracker'),('child_light','child_light'),('child_ambient','child_ambient'),('child_volume','child_volume'),('child_beacon','child_beacon'),('child_no_fog_clip','child_no_fog_clip'),('lib_ungroupable','lib_ungroupable'),('has_light','has_light'),('has_ambient','has_ambient'),('has_cubemap','has_cubemap'),('cubemap_generation_size','cubemapGenSize'),('cubemap_capture_size','cubemapCaptureSize'),('has_sound','has_sound'),('sound_volume','sound_vol'),('sound_exclude','sound_exclude'),('has_fog','has_fog'),('has_volume','has_volume'),('has_beacon','has_beacon'),('has_tint_color','has_tint_color'),('has_tex','has_tex'),('has_alpha','has_alpha'),('has_properties','has_properties'),('hide_for_gameplay','hideForGameplay')]
META_FLOAT = [('lod_scale','lod_scale'),('lod_near','lod_near'),('lod_far','lod_far'),('lod_nearfade','lod_nearfade'),('lod_farfade','lod_farfade'),('sound_radius','sound_radius'),('shadow_dist','shadow_dist'),('light_radius','light_radius'),('cubemap_blur_angle','cubemapBlurAngle'),('cubemap_capture_time','cubemapCaptureTime'),('sound_ramp','sound_ramp'),('fog_near','fog_near'),('fog_far','fog_far'),('fog_radius','fog_radius'),('fog_speed','fog_speed'),('box_scale[0]','box_scale[0]'),('box_scale[1]','box_scale[1]'),('box_scale[2]','box_scale[2]'),('beacon_radius','beacon_radius'),('alpha','groupdef_alpha')]
META_STRING = [('type_name','type_name'),('sound_name','sound_name'),('sound_script','sound_script_filename'),('beacon_name','beacon_name'),('textures[0]','tex_names[0]'),('textures[1]','tex_names[1]'),('geometry','model ? d->model->name : NULL')]
def metadata_fixtures(source_root,directory,source):
    body=(HERE/'tests/metadata_source_harness.inc').read_text()
    body += '\nvoid metadata_fields(U32 *u,float *f,char *strings,U8 *colors){GroupDef *d=metadata_definition;\n'
    body += ''.join('u[%d]=d->%s;\n'%(i,field) for i,(_,field) in enumerate(META_U32))
    body += ''.join('f[%d]=d->%s;\n'%(i,field) for i,(_,field) in enumerate(META_FLOAT))
    for i,(_,field) in enumerate(META_STRING):body += '{const char *value=d->'+field+';if(value)strcpy(strings+'+str(i*256)+',value); }\n'
    body+='memcpy(colors,d->color,8); }\n'
    original=directory/'metadata-original.c';original.write_text(source.read_text()+'\n'+body)
    libpath=directory/'metadata-original.so'
    run(['cc','-std=c99','-O0','-fno-strict-aliasing','-fPIC','-shared','-w','-I'+str(source_root/'native-android/include'),str(original),'-lm','-lz','-o',str(libpath)])
    lib=C.CDLL(str(libpath));lib.metadata_original.argtypes=[C.c_uint32,C.c_uint32,C.c_void_p,C.POINTER(C.c_uint32)];lib.metadata_fields.argtypes=[C.c_void_p]*4
    header=directory/'scenegraph_fixtures.h';lines=[];rows=[]
    lines.append('typedef struct {const unsigned char *wire;size_t bytes,bits;unsigned aligned,which;uint32_t u['+str(len(META_U32))+'];float f['+str(len(META_FLOAT))+'];char strings[7][256];uint8_t colors[8];} MetadataFixture;\n')
    for which in range(7):
      for aligned in (0,1):
        wire=(C.c_uint8*(1<<20))();bits=C.c_uint32();u=(C.c_uint32*len(META_U32))();f=(C.c_float*len(META_FLOAT))();strings=(C.c_uint8*(7*256))();colors=(C.c_uint8*8)()
        assert lib.metadata_original(which,aligned,wire,C.byref(bits))==1
        lib.metadata_fields(u,f,strings,colors)
        raw=bytes(wire[:(bits.value+7)//8]);i=len(rows);name='metadata_wire_'+str(i)
        lines.append('static const unsigned char '+name+'[]={'+','.join(map(str,raw))+'};\n')
        texts=[bytes(strings[j*256:(j+1)*256]).split(b'\0',1)[0].decode() for j in range(7)]
        rows.append('{'+','.join([name,str(len(raw)),str(bits.value),str(aligned),str(which),'{'+','.join(map(str,u))+'}','{'+','.join(float(v).hex()+'f' for v in f)+'}','{'+','.join(json.dumps(x) for x in texts)+'}','{'+','.join(map(str,colors))+'}'])+'}')
    lines.append('static const MetadataFixture metadata_fixtures[]={'+',\n'.join(rows)+'};\n')
    for name,fields,accessor in [('u32',META_U32,'u'),('float',META_FLOAT,'f'),('string',META_STRING,'strings')]:
        lines.append('#define METADATA_COMPARE_'+name.upper()+'(m,expected,CHECK) do {')
        for i,(field,_) in enumerate(fields):lines.append('CHECK('+('strcmp((m)->'+field+', (expected)->strings['+str(i)+'])==0' if name=='string' else '(m)->'+field+'==(expected)->'+accessor+'['+str(i)+']')+');')
        lines.append('} while(0)\n')
    with header.open('a') as out:out.write(''.join(lines))
    return {'fixtures':len(rows),'producer_body':'unchanged original sendDef; source objects read independently after serialization','consumer_body_executed':False,'source_extension_sha256':hashlib.sha256(body.encode()).hexdigest(),'harness_sha256':hashlib.sha256((HERE/'tests/metadata_source_harness.inc').read_bytes()).hexdigest()}

def prepare(source_root,directory):
    spec=importlib.util.spec_from_file_location('sg_original_groups',HERE.parent/'replication/groups_oracle.py')
    oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
    fixtures,receipt=oracle.produce_fixtures(source_root,directory)
    # Extend trusted input harness only; source producer function bodies/pins stay exact.
    src=directory/'groups-original.c'
    extra='''
int scenegraph_baseline(U32 aligned,U32 legacy,U8 *out,U32 *bits) {
 U32 footer[4];if(!groups_original(4,aligned,legacy,out,bits,footer))return 0;
 oracle_defs[1].in_use=1;oracle_refs[2].def=&oracle_defs[1];
 NetLink link={0};worldSendUpdate(&link,aligned?1:0);
 *bits=oracle_packet.stream.bitLength;memcpy(out,oracle_storage,(*bits+7)/8);return 1;
}
int scenegraph_long_property(U32 aligned,U32 legacy,U8 *out,U32 *bits) {
 U32 footer[4];static char long_value[1024];if(!groups_original(2,aligned,legacy,out,bits,footer))return 0;
 memset(long_value,'x',sizeof(long_value)-1);oracle_prop_entries[0][0].value_str=long_value;
 NetLink link={0};worldSendUpdate(&link,aligned?1:0);
 *bits=oracle_packet.stream.bitLength;memcpy(out,oracle_storage,(*bits+7)/8);return 1;
}
void scenegraph_source_roots(float *out) {memcpy(out,oracle_refs[0].mat,48);memcpy(out+12,oracle_refs[1].mat,48);memcpy(out+24,oracle_refs[2].mat,48);}
'''
    src.write_text(src.read_text()+extra)
    libpath=directory/'scenegraph-original.so'
    run(['cc','-std=c99','-O0','-fno-strict-aliasing','-fPIC','-shared','-w','-I'+str(source_root/'native-android/include'),str(src),'-lm','-lz','-o',str(libpath)])
    lib=C.CDLL(str(libpath));lib.scenegraph_baseline.argtypes=[C.c_uint32,C.c_uint32,C.c_void_p,C.POINTER(C.c_uint32)]
    lib.scenegraph_long_property.argtypes=[C.c_uint32,C.c_uint32,C.c_void_p,C.POINTER(C.c_uint32)]
    lib.groups_original.argtypes=[C.c_uint32,C.c_uint32,C.c_uint32,C.c_void_p,C.POINTER(C.c_uint32),C.POINTER(C.c_uint32)]
    lib.scenegraph_source_roots.argtypes=[C.POINTER(C.c_float)]
    for aligned in (0,1):
        for legacy in (0,1):
            raw=(C.c_uint8*(1<<20))();bits=C.c_uint32()
            assert lib.scenegraph_baseline(aligned,legacy,raw,C.byref(bits))==1
            fixtures.append(dict(name='incremental_baseline',source_case=11,representation='byte_aligned' if aligned else 'packed',legacy_commands=legacy,payload_hex=bytes(raw[:(bits.value+7)//8]).hex(),payload_bits=bits.value))
    for aligned in (0,1):
        for legacy in (0,1):
            raw=(C.c_uint8*(1<<20))();bits=C.c_uint32()
            assert lib.scenegraph_long_property(aligned,legacy,raw,C.byref(bits))==1
            fixtures.append(dict(name='long_property',source_case=12,representation='byte_aligned' if aligned else 'packed',legacy_commands=legacy,payload_hex=bytes(raw[:(bits.value+7)//8]).hex(),payload_bits=bits.value))
    raw=(C.c_uint8*(1<<20))();bits=C.c_uint32();footer=(C.c_uint32*4)();mat=(C.c_float*36)()
    assert lib.groups_original(7,1,0,raw,C.byref(bits),footer)==1
    lib.scenegraph_source_roots(mat)
    lines=['typedef struct {const char *name;const unsigned char *data;size_t bytes,bits;unsigned aligned,legacy,which;} Fixture;\n']
    rows=[]
    for i,f in enumerate(fixtures):
        raw=bytes.fromhex(f['payload_hex']);name='sgfixture_'+str(i)
        lines.append('static const unsigned char '+name+'[]={'+','.join(map(str,raw))+'};\n')
        rows.append('{'+','.join([json.dumps(f['name']),name,str(len(raw)),str(f['payload_bits']),str(int(f['representation']=='byte_aligned')),str(f['legacy_commands']),str(f['source_case'])])+'}')
    lines.append('static const Fixture fixtures[]={'+',\n'.join(rows)+'};\n')
    lines.append('static const float source_matrices[3][4][3]={'+','.join('{'+','.join('{'+','.join(float(mat[k*12+i*3+j]).hex()+'f' for j in range(3))+'}' for i in range(4))+'}' for k in range(3))+'};\n')
    (directory/'scenegraph_fixtures.h').write_text(''.join(lines))
    # Reuse the exact catalog producer and independently invoke unchanged sendDef
    # for every stress record. Separate temporary scope is safe under parallel CI.
    catdir=directory/'catalog-source';catdir.mkdir()
    cspec=importlib.util.spec_from_file_location('graph_catalog_oracle',HERE.parent/'scenecatalog/check.py')
    catalog=importlib.util.module_from_spec(cspec);cspec.loader.exec_module(catalog)
    catreceipt,_=catalog.prepare(source_root,catdir)
    clib=C.CDLL(str(catdir/'catalog-original.so'))
    clib.catalog_original.argtypes=[C.c_uint32]*4+[C.c_void_p,C.POINTER(C.c_uint32),C.c_void_p,C.POINTER(C.c_uint32),C.c_void_p]
    clib.catalog_record_original.argtypes=[C.c_uint32,C.c_uint32,C.c_void_p,C.POINTER(C.c_uint32)]
    buf=(C.c_uint8*(32<<20))();wire=(C.c_uint8*(1<<20))();size=C.c_uint32();bits=C.c_uint32();counts=(C.c_uint32*7)()
    assert clib.catalog_original(20,1,0,0,buf,C.byref(size),wire,C.byref(bits),counts)==0
    raw=bytes(buf[:size.value]);w=bytes(wire[:(bits.value+7)//8]);at=48;compared=0
    direct=(C.c_uint8*(4<<20))();direct_size=C.c_uint32()
    for f in range(struct.unpack_from('<I',raw,24)[0]):
        index,checksum,slots,records,length=struct.unpack_from('<5I',raw,at);assert index==f;at+=20+length
        for _ in range(records):
            slot,rbits,rbytes,ralign=struct.unpack_from('<4I',raw,at);at+=16
            assert clib.catalog_record_original(f,slot,direct,C.byref(direct_size))==1
            assert direct_size.value==rbytes and bytes(direct[:rbytes])==raw[at:at+rbytes]
            at+=rbytes;compared+=1
    assert at==len(raw) and compared==12192
    with (directory/'scenegraph_fixtures.h').open('a') as f:
        for name,payload in [('stress_catalog',raw),('stress_wire',w)]:
            f.write('static const unsigned char '+name+'[]={'+','.join(map(str,payload))+'};\n')
        f.write('static const size_t stress_wire_bits='+str(bits.value)+';\n')
    receipt['stress_catalog']={'producer':catreceipt,'source_counts':list(counts),'catalog_sha256':hashlib.sha256(raw).hexdigest(),'wire_sha256':hashlib.sha256(w).hexdigest(),'independent_record_comparisons':compared,'real_server_capture':False}
    receipt['metadata_oracle']=metadata_fixtures(source_root,directory,src)
    receipt['graph_extension_sha256']=hashlib.sha256(extra.encode()).hexdigest()
    receipt['graph_fixture_header_sha256']=hashlib.sha256((directory/'scenegraph_fixtures.h').read_bytes()).hexdigest()
    return receipt,len(fixtures)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-root',type=Path,default=REPO);ap.add_argument('--output',type=Path);ap.add_argument('--sanitize',action='store_true');ap.add_argument('--ndk',type=Path);ap.add_argument('--android-output',type=Path);ap.add_argument('--fixtures-output',type=Path);ap.add_argument('--prepare-only',action='store_true');a=ap.parse_args()
    with tempfile.TemporaryDirectory(prefix='coh-sg-') as temp:
        d=Path(temp);receipt,n=prepare(a.source_root.resolve(),d)
        lookup_spec=importlib.util.spec_from_file_location('graph_lookup_oracle',HERE/'check_lookup.py')
        lookup_module=importlib.util.module_from_spec(lookup_spec);lookup_spec.loader.exec_module(lookup_module)
        receipt['lookup_oracle']=lookup_module.prepare(a.source_root.resolve(),d)
        lookup_fixture_sha=receipt['lookup_oracle']['fixtures_sha256']
        if a.fixtures_output:
            a.fixtures_output.mkdir(parents=True,exist_ok=True);shutil.copyfile(d/'scenegraph_fixtures.h',a.fixtures_output/'scenegraph_fixtures.h')
            shutil.copyfile(d/'lookup_fixtures.h',a.fixtures_output/'lookup_fixtures.h')
        if a.prepare_only:
            if not a.fixtures_output:ap.error('--prepare-only requires --fixtures-output')
            return
        sources=[HERE/'coh_scene_compact.c',HERE/'tests/test_scene_compact.c',HERE/'coh_scenegraph.c',HERE/'coh_scene_metadata.c',HERE/'coh_scene_lookup.c',HERE/'tests/test_scene_lookup.c',HERE.parent/'scenecatalog/coh_scenecatalog.c',HERE.parent/'replication/coh_replication.c',HERE.parent/'replication/coh_groups.c',HERE/'tests/test_scenegraph.c']
        hashed_sources=[*sources,HERE/'coh_scenegraph.h',HERE/'coh_scene_metadata.h',HERE/'tests/metadata_source_harness.inc',HERE/'tests/reader_padding_control.c',HERE/'check.py',HERE.parent/'replication/coh_replication.h',HERE.parent/'replication/coh_groups.h',HERE.parent/'replication/groups-source-pins.json',HERE.parent/'scenecatalog/coh_scenecatalog.h',HERE.parent/'scenecatalog/check.py',HERE.parent/'scenecatalog/source_export.inc',HERE.parent/'scenecatalog/tests/source_catalog_harness.c']
        hashed_sources += [HERE/'coh_scene_compact.h',HERE/'check_compact.py',HERE/'tests/compact_missing_audit.c',HERE/'coh_scene_lookup.h',HERE/'tests/lookup_oracle_shim.h',HERE/'check_lookup.py',HERE/'lookup-source-pins.json',HERE/'CMakeLists.txt',HERE.parent/'coh_contracts.h']
        source_hashes={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in hashed_sources}
        fixture_sha=hashlib.sha256((d/'scenegraph_fixtures.h').read_bytes()).hexdigest()
        flags=['-std=c99','-Wall','-Wextra','-Werror','-pedantic','-I'+str(d),'-I'+str(HERE),'-Wl,--wrap=malloc,--wrap=calloc,--wrap=free']
        modes=[('release',['-O2'])]
        if a.sanitize:modes += [('asan',['-O1','-g','-fno-omit-frame-pointer','-fsanitize=address','-no-pie']),('ubsan',['-O1','-g','-fno-omit-frame-pointer','-fsanitize=undefined','-fno-sanitize-recover=all'])]
        checks={}
        for name,extra in modes:
            binary=d/name;run([os.environ.get('CC','cc'),*flags,*extra,*map(str,sources),'-lm','-o',str(binary)])
            env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
            checks[name]=json.loads(run([str(binary)],env=env).stdout)
        # A valid reader may carry different padding after each initialization.
        # This host-only control exercises byte rollback independently of the
        # compiler's ordinary choice of struct object representation.
        padding_binary=d/'reader-padding';padding_source=HERE/'tests/reader_padding_control.c'
        run([os.environ.get('CC','cc'),*flags,'-O2','-Wl,--wrap=coh_rep_reader_bounded',*map(str,sources),str(padding_source),'-lm','-o',str(padding_binary)])
        checks['reader_padding']=json.loads(run([str(padding_binary)]).stdout)
        android=[]
        if a.ndk:
            if not a.android_output:ap.error('--ndk requires --android-output')
            a.android_output.mkdir(parents=True,exist_ok=True);shutil.copyfile(d/'scenegraph_fixtures.h',a.android_output/'scenegraph_fixtures.h')
            shutil.copyfile(d/'lookup_fixtures.h',a.android_output/'lookup_fixtures.h')
            for abi,triple in [('arm64-v8a','aarch64-linux-android26'),('x86_64','x86_64-linux-android26')]:
                out=a.android_output/abi;out.mkdir(parents=True,exist_ok=True);binary=out/'coh_scenegraph_test'
                cc=a.ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin'/str(triple+'-clang')
                run([str(cc),*flags,'-O2',*map(str,sources),'-lm','-o',str(binary)])
                r={'passed':True,'abi':abi,'binary':binary.name,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'execution_qualified':False,'fixtures_sha256':fixture_sha,'lookup_fixtures_sha256':lookup_fixture_sha,'source_sha256':source_hashes}
                (out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');android.append(r)
        result={'schema':1,'passed':True,'scope':'dynamic indexed GROUPS topology and copied model/library lookup metadata; source-produced synthetic 508-file catalog imported with aggregate ownership admission, not live server world','source_oracle':receipt,'fixtures':n,'fixtures_sha256':fixture_sha,'lookup_fixtures_sha256':lookup_fixture_sha,'source_sha256':source_hashes,'checks':checks,'android_builds':android,'leak_sanitizer':False,'leak_sanitizer_reason':'host ptrace environment denies /proc thread enumeration; every module allocation is independently wrapped/counted and failures injected','catalog_import_adapter_tested':True,'real_import_adapter':False,'renderer_authorized':False,'real_server_capture':False,'thor_accepted':False}
        if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
if __name__=='__main__':main()
