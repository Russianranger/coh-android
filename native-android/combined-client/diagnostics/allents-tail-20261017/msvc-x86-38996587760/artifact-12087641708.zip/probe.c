#include <stdio.h>
#include <string.h>
#if !defined(_MSC_VER) || defined(__clang__) || !defined(_WIN32) || !defined(_M_IX86)
#error This qualification requires actual MSVC targeting Windows x86.
#endif
#ifndef _MSC_BUILD
#define _MSC_BUILD 0
#endif
typedef unsigned char U8;
#define GRPDYN_HP_BITS 7
#define GRPDYN_REPAIR_BITS 1
#pragma warning(push)
#pragma warning(disable:4214) /* Original U8 bitfield extension, retained verbatim. */
typedef struct
{
    U8        hp : GRPDYN_HP_BITS;
    U8        repair : GRPDYN_REPAIR_BITS;
} DynGroupStatus;
#pragma warning(pop)

typedef char require_status_size_1[(sizeof(DynGroupStatus)==1)?1:-1];
typedef char require_pointer_size_4[(sizeof(void*)==4)?1:-1];
int main(void){
 unsigned i;char hex[513];static const char digits[]="0123456789abcdef";
 for(i=0;i<256;i++){
  DynGroupStatus value;unsigned char raw;memset(&value,0,sizeof(value));
  value.hp=(unsigned char)(i&127u);value.repair=(unsigned char)(i>>7);
  memcpy(&raw,&value,1);
  if((unsigned)raw!=i)return 20;
  hex[i*2]=digits[raw>>4];hex[i*2+1]=digits[raw&15u];
  raw=(unsigned char)i;memcpy(&value,&raw,1);
  if((unsigned)value.hp!=(i&127u)||(unsigned)value.repair!=(i>>7))return 21;
 }
 hex[512]=0;
 printf("{\"passed\":true,\"patterns\":256,\"reverse_patterns\":256,\"status_bytes\":%u,\"pointer_bytes\":%u,\"msc_ver\":%u,\"msc_full_ver\":%u,\"msc_build\":%u,\"m_ix86\":%u,\"native_bytes_hex\":\"%s\"}\n",(unsigned)sizeof(DynGroupStatus),(unsigned)sizeof(void*),(unsigned)_MSC_VER,(unsigned)_MSC_FULL_VER,(unsigned)_MSC_BUILD,(unsigned)_M_IX86,hex);
 return 0;
}
