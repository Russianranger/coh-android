@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars32.bat"
if errorlevel 1 exit /b 1
python tools/android/game/test_mapserver_progress.py --require-windows
if errorlevel 1 exit /b 1
